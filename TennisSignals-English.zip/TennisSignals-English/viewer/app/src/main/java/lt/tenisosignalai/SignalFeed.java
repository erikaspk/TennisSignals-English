package lt.tenisosignalai;

import java.io.IOException;
import java.net.URI;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONObject;

final class SignalFeed {
    static JSONObject fetch(String url, String memberToken, String etag) throws Exception {
        HttpsURLConnection connection = RelayHttp.open(RelayHttp.base(url), "/v1/feed", memberToken);
        if (BuildConfig.DIRECT_PAYMENT) connection.setRequestProperty("X-Checkout-Mode", "direct");
        if (!etag.isEmpty()) connection.setRequestProperty("If-None-Match", etag);
        try {
            int code = connection.getResponseCode();
            if (code == 304) return null;
            if (code != 200) throw new IOException("Feed request failed");
            JSONObject feed = new JSONObject(RelayHttp.read(connection.getInputStream()));
            if (feed.optInt("schema") != 1 || feed.optJSONArray("signals") == null)
                throw new IOException("Invalid feed");
            String tag = connection.getHeaderField("ETag");
            if (tag != null) feed.put("etag", tag);
            return feed;
        } finally { connection.disconnect(); }
    }

    static URI checkout(String url) {
        URI uri = URI.create(url);
        String host = uri.getHost();
        if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getUserInfo() != null || host == null)
            throw new IllegalArgumentException("Invalid checkout URL");
        host = host.toLowerCase(java.util.Locale.ROOT);
        if (!(host.equals("revolut.me") || host.equals("revolut.com") || host.endsWith(".revolut.com")))
            throw new IllegalArgumentException("Revolut checkout URL required");
        return uri;
    }
}
