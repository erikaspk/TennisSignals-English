package lt.tenisosignalai;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.widget.*;
import android.graphics.Color;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public final class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        settings = getSharedPreferences("monitor", MODE_PRIVATE);
        if(state!=null){page=state.getInt("page",0);historyDate=state.getString("historyDate","");historyTier=state.getString("historyTier","");showOlder=state.getBoolean("showOlder",false);}
        if ("legacy".equals(historyTier)) historyTier = "";
        render();
    }

    private String historyDate="",historyTier="";
    private boolean showOlder;
    private final Set<String> expandedHistory=new HashSet<>();
    private ScrollView scrollView;
    private int renderedPage=-1;
    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);state.putInt("page",page);state.putString("historyDate",historyDate);
        state.putString("historyTier",historyTier);state.putBoolean("showOlder",showOlder);
    }
    private SharedPreferences settings;
    private LinearLayout panel;
    private int page;
    private final ScheduledExecutorService requests = Executors.newSingleThreadScheduledExecutor();
    private Future<?> refresh;
    private JSONObject feed = new JSONObject();
    private String feedMessage = "Connect the signal feed from Profile.";
    private volatile String etag = "";
    private int generation;

    @Override protected void onStart() {
        super.onStart();
        startRefresh();
    }

    @Override protected void onStop() {
        generation++;
        if (refresh != null) refresh.cancel(true);
        super.onStop();
    }

    @Override protected void onDestroy() {
        requests.shutdownNow();
        super.onDestroy();
    }

    private void startRefresh() {
        if (refresh != null) refresh.cancel(true);
        int current = ++generation;
        String address = settings.getString("relayUrl", BuildConfig.DEFAULT_RELAY_URL);
        String token = settings.getString("memberCode", "");
        if (address.isEmpty()) return;
        refresh = requests.scheduleWithFixedDelay(() -> {
            try {
                JSONObject next = SignalFeed.fetch(address, token, etag);
                runOnUiThread(() -> {
                    if (current != generation) return;
                    if (next == null && feedMessage.isEmpty()) return;
                    if (next != null) {
                        feed = next;
                        etag = next.optString("etag");
                    }
                    feedMessage = "";
                    render();
                });
            } catch (Exception unavailable) {
                runOnUiThread(() -> {
                    if (current != generation || "Feed unavailable. Retrying…".equals(feedMessage)) return;
                    feedMessage = "Feed unavailable. Retrying…";
                    render();
                });
            }
        }, 0, 15, TimeUnit.SECONDS);
    }

    private void render() {
        int previousScroll=scrollView!=null&&renderedPage==page?scrollView.getScrollY():0;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                new int[]{0xff080c24, 0xff121b48, 0xff0a102c}));
        getWindow().setStatusBarColor(0xff080c24);
        getWindow().setNavigationBarColor(0xff080c24);
        root.setFitsSystemWindows(true);
        ScrollView scroll = new ScrollView(this);
        scrollView=scroll;renderedPage=page;
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int padding = (int) (18 * getResources().getDisplayMetrics().density);
        panel.setPadding(padding, padding, padding, padding);
        scroll.addView(panel);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        String[] tabs = {"Live", "History", "Statistics", "Profile"};
        label("TENNIS SIGNALS   /   LIVE", 14);
        label(tabs[page].toUpperCase(Locale.US), 34);
        if (page == 0) live();
        if (page == 1 || page == 2) history();
        if (page == 3) profile();

        LinearLayout menu = new LinearLayout(this);
        menu.setBackgroundColor(0xff141a39);
        for (int i = 0; i < tabs.length; i++) {
            final int tab = i;
            Button button = new Button(this, null, android.R.attr.borderlessButtonStyle);
            button.setText(tabs[i]);
            button.setAllCaps(false);
            button.setTextColor(i == page ? 0xffa58aff : 0xffc7c7c7);
            button.setTextSize(13);
            button.setPadding(0, 0, 0, 0);
            button.setSelected(i == page);
            button.setMinWidth(0);
            button.setMinimumWidth(0);
            menu.addView(button, new LinearLayout.LayoutParams(0, -2, 1));
            button.setOnClickListener(view -> { page = tab; render(); });
        }
        root.addView(menu);
        setContentView(root);
        scroll.post(()->scroll.scrollTo(0,previousScroll));
    }

    private void label(String text, int size) {
        label(text, size, size >= 22 ? 0xffa58aff : 0xffeeeeee);
    }

    private void label(String text, int size, int color) {
        TextView line = new TextView(this);
        line.setText(text);
        line.setTextSize(size);
        line.setTextColor(color);
        if (size >= 18) line.setTypeface(android.graphics.Typeface.create(
                "sans-serif-condensed", android.graphics.Typeface.BOLD));
        line.setPadding(0, 8, 0, 12);
        panel.addView(line);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private android.graphics.drawable.GradientDrawable card(int border) {
        android.graphics.drawable.GradientDrawable shape = new android.graphics.drawable.GradientDrawable();
        shape.setColors(new int[]{0xff20264d, 0xff131a36});
        shape.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TL_BR);
        shape.setCornerRadius(dp(18));
        shape.setStroke(dp(1), border);
        return shape;
    }

    private void live() {
        if (!feedMessage.isEmpty()) label(feedMessage, 14);
        long updated = feed.optLong("updated");
        if (updated > 0) label("Publisher updated " + java.text.DateFormat.getDateTimeInstance()
                .format(new Date(updated * 1000L)), 13);
        int count = 0;
        for (JSONObject row : signalHistory()) {
            if (!feed.optBoolean("live") || updated < System.currentTimeMillis() / 1000L - 180 || !row.optString("outcome").equals("Vyksta")) continue;
            panel.addView(historyCard(row, false));
            count++;
        }
        if (count == 0) label("No active signals in your feed.", 16);
    }

    private List<JSONObject> signalHistory() {
        List<JSONObject> rows = new ArrayList<>();
        JSONArray signals = feed.optJSONArray("signals");
        if (feed.optBoolean("member") && feed.optLong("expires") <= System.currentTimeMillis() / 1000L) return rows;
        if (signals != null) for (int i = 0; i < signals.length(); i++) {
            JSONObject row = signals.optJSONObject(i);
            if (row != null) rows.add(row);
        }
        return rows;
    }

    private String overallRoi(List<JSONObject> rows) {
        double profit = 0;
        double stakes = 0;
        for (JSONObject row : rows) {
            String outcome = SignalText.outcome(row);
            if (!"Won".equals(outcome) && !"Lost".equals(outcome)) continue;
            double stake = row.optJSONObject("bet").optDouble("stake", 10);
            if (!Double.isFinite(stake) || stake <= 0) continue;
            profit += row.optDouble("profit");
            stakes += stake;
        }
        return stakes == 0 ? "—" : String.format(Locale.US, "%+.1f %%", 100 * profit / stakes);
    }

    private void history() {
        List<JSONObject> all = signalHistory();
        List<JSONObject> rows = SignalPolicy.filter(all, historyDate, historyTier);
        historyFilters();
        List<android.view.View> olderTableRows=new ArrayList<>();
        int wins = 0, losses = 0, pending = 0, interrupted = 0, withoutAh = 0;
        for (JSONObject row : rows) {
            String outcome = SignalText.outcome(row);
            switch (outcome) {
                case "Won": wins++; break;
                case "Lost": losses++; break;
                case "Refunded": interrupted++; break;
                case "No pick": withoutAh++; break;
                default: pending++;
            }
        }
        int full=Math.min(5,rows.size());
        for(int i=0;i<full;i++)panel.addView(historyCard(rows.get(i),false));
        if(rows.size()>5) {
            Button older=new Button(this);older.setAllCaps(false);
            older.setText((showOlder?"▴ Hide older signals":"▾ Older signals")+" ("+(rows.size()-5)+")");
            LinearLayout archive=new LinearLayout(this);archive.setOrientation(LinearLayout.VERTICAL);
            archive.setVisibility(showOlder?android.view.View.VISIBLE:android.view.View.GONE);
            for(int i=5;i<rows.size();i++)archive.addView(historyCard(rows.get(i),true));
            older.setOnClickListener(v->{showOlder=!showOlder;archive.setVisibility(showOlder?android.view.View.VISIBLE:android.view.View.GONE);
                for(android.view.View row:olderTableRows)row.setVisibility(showOlder?android.view.View.VISIBLE:android.view.View.GONE);
                older.setText((showOlder?"▴ Hide older signals":"▾ Older signals")+" ("+archive.getChildCount()+")");});
            panel.addView(older);panel.addView(archive);
        }
        if(rows.isEmpty())label("No signals match these filters.",16);
        if (page == 1 && rows.isEmpty()) label("Signal history is empty.", 16);
        if (page == 2) {
            label("€10 MODEL STAKE PER PICK", 22);
            TableLayout table = new TableLayout(this);
            table.setStretchAllColumns(true);
            String[] headers = {"Signal / AH / ML", "Odds", "Profit"};
            TableRow header = new TableRow(this);
            for (String text : headers) {
                TextView cell = new TextView(this);
                cell.setText(text); cell.setTextColor(0xffa58aff); cell.setPadding(4, 12, 4, 12);
                header.addView(cell);
            }
            table.addView(header);
            int tableIndex=0;
            double oddsSum = 0;
            int oddsCount = 0;
            for (JSONObject row : rows) {
                JSONObject bet = row.optJSONObject("bet");
                double odds = bet == null ? Double.NaN : bet.optDouble("odds", Double.NaN);
                if (Double.isFinite(odds) && odds > 1) {
                    oddsSum += odds;
                    oddsCount++;
                }
                TableRow tr = new TableRow(this);
                String title = SignalText.english(row.optString("title"));
                String[] cells = {title + (bet == null ? "" : "\n"+SignalText.label(bet)),
                        bet == null ? "—" : String.format(Locale.ROOT, "%.2f\n%s", bet.optDouble("odds"), bet.optString("bookmaker", "")),
                        row.has("profit") ? String.format(Locale.ROOT, "%+.2f €", row.optDouble("profit")) : "—"};
                for (int column = 0; column < cells.length; column++) {
                    TextView cell = new TextView(this);
                    cell.setText(cells[column]); cell.setTextSize(12); cell.setTextColor(0xffeeeeff);
                    cell.setPadding(4, 10, 4, 10);
                    if (column == 0) cell.setMaxWidth(dp(175));
                    tr.addView(cell);
                }
                if(tableIndex++>=5){tr.setVisibility(showOlder?android.view.View.VISIBLE:android.view.View.GONE);olderTableRows.add(tr);}
                table.addView(tr);
            }
            panel.addView(table);
            label("Average odds · " + (oddsCount == 0 ? "—"
                    : String.format(Locale.US, "%.2f", oddsSum / oddsCount)), 18);
            label("Green and Yellow C · Cumulative model profit by signal date. Signals without odds are excluded.", 14);
            List<JSONObject> chronological = new ArrayList<>(rows);
            Collections.reverse(chronological);
            panel.addView(new ProfitChart(this, chronological,historyTier), new LinearLayout.LayoutParams(-1, dp(240)));
            for (String tier : new String[]{"green", "yellow"}) {
                if(!historyTier.isEmpty()&&!historyTier.equals(tier))continue;
                double profit = 0;
                int settled = 0;
                for (JSONObject row : rows) {
                    if (tier.equals(row.optString("tier")) && row.has("profit")) {
                        profit += row.optDouble("profit");
                        settled++;
                    }
                }
                label(String.format(Locale.US, "%s · %d settled · %+.2f €", 
                        tier.equals("green") ? "Green" : tier.equals("yellow") ? "Yellow" : "Brown", settled, profit), 16);
                android.view.View filterLabel=panel.getChildAt(panel.getChildCount()-1);
                filterLabel.setContentDescription("Filter by "+tier+" signals");
                filterLabel.setOnClickListener(v->{historyTier=historyTier.equals(tier)?"":tier;showOlder=false;render();});
            }
            label("Overall ROI · " + overallRoi(all), 22);
            int completed = wins + losses;
            label(completed == 0 ? "AH / ML hit rate: —" : String.format(Locale.US,
                    "AH / ML hit rate: %.1f %% (%d of %d)", wins * 100.0 / completed, wins, completed), 22);
            label("Won: " + wins + " · Lost: " + losses
                    + "\nPending: " + pending + " · Refunded: " + interrupted + "\nNo pick: " + withoutAh, 16);
        }
    }

    private void profile() {
        profileIdentity();
        label("Membership", 22);
        if (!feedMessage.isEmpty()) label(feedMessage, 14);
        if (feed.optBoolean("member") && feed.optLong("expires") > System.currentTimeMillis() / 1000L) {
            long expires = feed.optLong("expires");
            label(expires > 0 ? "Member access until " + java.text.DateFormat.getDateTimeInstance()
                    .format(new Date(expires * 1000L)) : "Member access active", 16);
        } else {
            label("Free · Follow up to 3 matches at a time\nMembership · Full signal feed and history", 16);
            if (!settings.getString("memberCode", "").isEmpty() && feed.has("member"))
                label("This access code is invalid or expired.", 14);
        }
        label("€4.99 for 7 days · €9.99 for 30 days", 16);
        if (BuildConfig.DIRECT_PAYMENT) {
            JSONObject checkout = feed.optJSONObject("checkout");
            JSONObject transfer = feed.optJSONObject("transfer");
            membershipPlan("7 days · €4.99", checkout == null ? "" : checkout.optString("week"), transfer, "7D", "4.99");
            membershipPlan("30 days · €9.99", checkout == null ? "" : checkout.optString("month"), transfer, "30D", "9.99");
            if (transfer == null && (checkout == null || (checkout.optString("week").isEmpty() && checkout.optString("month").isEmpty())))
                label("Checkout is not available.", 14);
            else label("Enter the access code provided by the publisher after payment.", 14);
        }
        Button connect = new Button(this);
        connect.setText("Feed connection / Access code");
        panel.addView(connect);
        connect.setOnClickListener(v -> connectionDialog());
    }

    private void membershipPlan(String title, String address, JSONObject transfer, String plan, String amount) {
        java.net.URI validated = null;
        if (!address.isEmpty()) {
            try { validated = SignalFeed.checkout(address); }
            catch (IllegalArgumentException ignored) { }
        }
        final java.net.URI checkout = validated;
        if (checkout == null && transfer == null) return;
        Button button = new Button(this);
        button.setText(title + (checkout == null ? " · Bank transfer" : " · Pay with Revolut"));
        panel.addView(button);
        button.setOnClickListener(v -> {
            if (checkout != null) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(checkout.toASCIIString()))); }
                catch (android.content.ActivityNotFoundException unavailable) {
                    Toast.makeText(this, "No browser available.", Toast.LENGTH_LONG).show();
                }
                return;
            }
            String reference = settings.getString("paymentReference", "");
            if (reference.isEmpty()) {
                reference = UUID.randomUUID().toString().substring(0, 8).toUpperCase(Locale.ROOT);
                settings.edit().putString("paymentReference", reference).apply();
            }
            String details = "Beneficiary: " + transfer.optString("beneficiary")
                    + "\nIBAN: " + transfer.optString("iban") + "\nBIC/SWIFT: " + transfer.optString("bic")
                    + "\nAmount: EUR " + amount + "\nReference: TENNIS-" + plan + "-" + reference;
            new android.app.AlertDialog.Builder(this).setTitle("Pay by bank transfer")
                    .setMessage(details + "\n\nUse the exact reference. The publisher provides your access code after checking the payment.")
                    .setNegativeButton("Close", null)
                    .setPositiveButton("Copy details", (dialog, which) -> {
                        android.content.ClipboardManager clipboard = getSystemService(android.content.ClipboardManager.class);
                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Bank transfer", details));
                    }).show();
        });
    }

    private void connectionDialog() {
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        EditText url = new EditText(this);
        url.setSingleLine(true);
        url.setHint("HTTPS feed address");
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setText(settings.getString("relayUrl", BuildConfig.DEFAULT_RELAY_URL));
        EditText code = new EditText(this);
        code.setSingleLine(true);
        code.setHint("Member access code (optional)");
        code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        code.setText(settings.getString("memberCode", ""));
        fields.addView(url);
        fields.addView(code);
        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                .setTitle("Connect to your publisher").setView(fields)
                .setNegativeButton("Cancel", null).setPositiveButton("Save", null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(-1).setOnClickListener(save -> {
            String address = url.getText().toString().trim();
            String token = code.getText().toString().trim();
            if (!address.isEmpty()) {
                try { address = RelayHttp.base(address).toString(); }
                catch (IllegalArgumentException invalid) { url.setError("Enter a valid HTTPS address"); return; }
                if (!token.isEmpty() && !token.matches("[A-Za-z0-9_-]{32,256}")) {
                    code.setError("Check your access code");
                    return;
                }
            }
            settings.edit().putString("relayUrl", address).putString("memberCode", address.isEmpty() ? "" : token).apply();
            feed = new JSONObject();
            etag = "";
            feedMessage = address.isEmpty() ? "Connect the signal feed from Profile." : "Connecting…";
            dialog.dismiss();
            startRefresh();
            render();
        }));
        dialog.show();
    }

    private void historyFilters() {
        LinearLayout dates=new LinearLayout(this);
        Button date=new Button(this);date.setAllCaps(false);date.setText(historyDate.isEmpty()?"📅 All dates":historyDate);
        date.setOnClickListener(v->{
            Calendar c=Calendar.getInstance(TimeZone.getTimeZone("Europe/Vilnius"));
            if(!historyDate.isEmpty())try{String[] d=historyDate.split("-");c.set(Integer.parseInt(d[0]),Integer.parseInt(d[1])-1,Integer.parseInt(d[2]));}catch(Exception ignored){}
            new android.app.DatePickerDialog(this,(picker,year,month,day)->{
                historyDate=String.format(Locale.ROOT,"%04d-%02d-%02d",year,month+1,day);showOlder=false;render();
            },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
        });
        dates.addView(date,new LinearLayout.LayoutParams(0,-2,1));
        Button clear=new Button(this);clear.setAllCaps(false);clear.setText("All dates");
        clear.setOnClickListener(v->{historyDate="";showOlder=false;render();});dates.addView(clear);
        panel.addView(dates);
        LinearLayout colors=new LinearLayout(this);
        String[] tiers={"","green","yellow"},names={"All","Green","Yellow C"};
        int[] tint={0xffa58aff,0xffa5ff40,0xffffd44d};
        for(int i=0;i<tiers.length;i++) {
            String tier=tiers[i];Button button=new Button(this,null,android.R.attr.borderlessButtonStyle);
            button.setText(names[i]);button.setAllCaps(false);button.setTextSize(12);button.setMinWidth(0);button.setMinimumWidth(0);
            button.setPadding(0,dp(8),0,dp(8));button.setTextColor(tint[i]);
            if(historyTier.equals(tier))button.setBackground(card(tint[i]));
            button.setOnClickListener(v->{historyTier=tier;showOlder=false;render();});colors.addView(button,new LinearLayout.LayoutParams(0,-2,1));
        }
        panel.addView(colors);
        label("By signal date · one signal per match",13);
    }
    private LinearLayout historyCard(JSONObject row,boolean collapsible) {
        String tier=row.optString("tier");int color=tier.equals("green")?0xffa5ff40:tier.equals("yellow")?0xffffd44d:0xff999999;
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams layout=new LinearLayout.LayoutParams(-1,-2);layout.bottomMargin=dp(14);box.setLayoutParams(layout);
        TextView heading=new TextView(this);heading.setTextColor(color);heading.setTextSize(18);
        heading.setTypeface(android.graphics.Typeface.create("sans-serif-condensed",android.graphics.Typeface.BOLD));
        heading.setIncludeFontPadding(true);heading.setPadding(dp(14),dp(10),dp(14),dp(10));
        heading.setBackground(card(color));heading.setLineSpacing(dp(2),1f);
        String key=SignalPolicy.key(row);boolean expanded=!collapsible||expandedHistory.contains(key);
        String title="AH / ML · "+SignalText.outcome(row)+" · "+SignalText.english(row.optString("title"));
        heading.setText((collapsible?(expanded?"▴ ":"▾ "):"")+title);
        box.addView(heading,new LinearLayout.LayoutParams(-1,-2));
        TextView detail=new TextView(this);detail.setTextSize(14);detail.setTextColor(0xffeeeeee);
        detail.setPadding(dp(5),dp(8),dp(5),dp(8));
        detail.setText(SignalText.english(row.optString("detail")) + "\nSource · " + row.optString("statsSource")
                + "\n" + SignalText.quote(row) + "\n" + SignalText.prematch(row)
                + (row.has("profit") ? String.format(Locale.US, " · %+.2f €", row.optDouble("profit")) : "")
                + "\n" + java.text.DateFormat.getDateTimeInstance().format(new Date(row.optLong("time"))));
        detail.setVisibility(expanded?android.view.View.VISIBLE:android.view.View.GONE);box.addView(detail);
        if(collapsible)heading.setOnClickListener(v->{boolean open=detail.getVisibility()!=android.view.View.VISIBLE;
            detail.setVisibility(open?android.view.View.VISIBLE:android.view.View.GONE);
            if(open)expandedHistory.add(key);else expandedHistory.remove(key);heading.setText((open?"▴ ":"▾ ")+title);});
        return box;
    }
    private void profileIdentity() {
        LinearLayout identity = new LinearLayout(this);
        identity.setOrientation(LinearLayout.VERTICAL);
        identity.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        identity.setPadding(dp(12), dp(16), dp(12), dp(20));

        TextView nickname = new TextView(this);
        nickname.setText(settings.getString("nickname", "Set a nickname"));
        nickname.setTextColor(0xffeeeeff);
        nickname.setTextSize(25);
        nickname.setGravity(android.view.Gravity.CENTER);
        nickname.setTypeface(null, android.graphics.Typeface.BOLD_ITALIC);
        nickname.setPadding(dp(8), dp(8), dp(8), dp(16));
        nickname.setOnClickListener(view -> {
            EditText input = new EditText(this);
            input.setSingleLine(true);
            input.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(30)});
            input.setText(settings.getString("nickname", ""));
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Nickname")
                    .setView(input)
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Save", (dialog, which) -> {
                        String value = input.getText().toString().trim();
                        if (!value.isEmpty()) {
                            settings.edit().putString("nickname", value).apply();
                            nickname.setText(value);
                        }
                    }).show();
        });
        identity.addView(nickname);

        FrameLayout ring = new FrameLayout(this);
        android.graphics.drawable.GradientDrawable border = new android.graphics.drawable.GradientDrawable();
        border.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        border.setColor(0xff14213d);
        border.setStroke(dp(5), 0xff00caff);
        ring.setBackground(border);
        ring.setPadding(dp(10), dp(10), dp(10), dp(10));

        java.io.File avatar = new java.io.File(getFilesDir(), "profile-avatar.jpg");
        android.view.View portrait;
        if (avatar.exists()) {
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setImageURI(android.net.Uri.fromFile(avatar));
            portrait = image;
        } else {
            TextView placeholder = new TextView(this);
            placeholder.setText("👤");
            placeholder.setTextSize(48);
            placeholder.setGravity(android.view.Gravity.CENTER);
            portrait = placeholder;
        }
        android.graphics.drawable.GradientDrawable circle = new android.graphics.drawable.GradientDrawable();
        circle.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        circle.setColor(0xff303c68);
        portrait.setBackground(circle);
        portrait.setClipToOutline(true);
        ring.addView(portrait, new FrameLayout.LayoutParams(-1, -1));
        ring.setContentDescription("Profile photo. Long press to change.");
        ring.setOnLongClickListener(view -> {
            new android.app.AlertDialog.Builder(this)
                    .setItems(new String[]{"Choose a photo"}, (dialog, which) -> {
                        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        pick.addCategory(Intent.CATEGORY_OPENABLE);
                        pick.setType("image/*");
                        try {
                            startActivityForResult(pick, 42);
                        } catch (android.content.ActivityNotFoundException missing) {
                            Toast.makeText(this, "No photo picker available", Toast.LENGTH_LONG).show();
                        }
                    }).show();
            return true;
        });
        identity.addView(ring, new LinearLayout.LayoutParams(dp(168), dp(168)));

        TextView roi = new TextView(this);
        roi.setText(overallRoi(signalHistory()) + "\nROI");
        roi.setTextColor(0xffeeeeff);
        roi.setTextSize(22);
        roi.setGravity(android.view.Gravity.CENTER);
        roi.setTypeface(null, android.graphics.Typeface.BOLD);
        roi.setPadding(dp(12), dp(10), dp(12), dp(10));
        roi.setBackground(card(0xff48618a));
        LinearLayout.LayoutParams roiLayout = new LinearLayout.LayoutParams(dp(164), -2);
        roiLayout.topMargin = dp(20);
        identity.addView(roi, roiLayout);
        panel.addView(identity);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request!=42||result!=RESULT_OK||data==null||data.getData()==null)return;
        android.graphics.Bitmap bitmap=null;
        java.io.File temporary=new java.io.File(getFilesDir(),"profile-avatar.tmp");
        try {
            android.graphics.BitmapFactory.Options options=new android.graphics.BitmapFactory.Options();options.inJustDecodeBounds=true;
            try(java.io.InputStream stream=getContentResolver().openInputStream(data.getData())){android.graphics.BitmapFactory.decodeStream(stream,null,options);}
            options.inSampleSize=1;while(Math.max(options.outWidth,options.outHeight)/options.inSampleSize>512)options.inSampleSize*=2;
            options.inJustDecodeBounds=false;
            try(java.io.InputStream stream=getContentResolver().openInputStream(data.getData())){bitmap=android.graphics.BitmapFactory.decodeStream(stream,null,options);}
            if(bitmap==null)throw new java.io.IOException("Could not read photo");
            try(java.io.OutputStream output=new java.io.FileOutputStream(temporary)){if(!bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG,90,output))throw new java.io.IOException("Could not save photo");}
            java.nio.file.Files.move(temporary.toPath(),new java.io.File(getFilesDir(),"profile-avatar.jpg").toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            render();
        }catch(Exception invalid){temporary.delete();Toast.makeText(this,"Could not import photo",Toast.LENGTH_LONG).show();}
        finally{if(bitmap!=null)bitmap.recycle();}
    }

}
