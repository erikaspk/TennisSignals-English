package lt.tenisosignalai;

import android.content.Context;
import android.graphics.*;
import android.view.View;
import java.util.*;
import org.json.*;

final class ProfitChart extends View {
    private final List<JSONObject> rows;
    private final String filter;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final String[] tiers = {"green", "yellow"};
    private final int[] colors = {0xffa5ff40, 0xffffd44d};

    ProfitChart(Context context, List<JSONObject> history) {
        this(context,history,"");
    }
    ProfitChart(Context context,List<JSONObject> history,String filter) {
        super(context);this.filter=filter;
        rows = history;
        setContentDescription("Cumulative model profit chart, using a €10 model stake per pick.");
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float density = getResources().getDisplayMetrics().density;
        float left = 55 * density, right = getWidth() - 12 * density;
        float top = 20 * density, bottom = getHeight() - 38 * density;
        double[] totals = new double[tiers.length];
        double min = -10, max = 10;
        List<double[]> values = new ArrayList<>();
        values.add(totals.clone());
        for (JSONObject row : rows) {
            if (!row.has("profit")) continue;
            for (int i = 0; i < tiers.length; i++) {
                if (tiers[i].equals(row.optString("tier"))) totals[i] += row.optDouble("profit");
                min = Math.min(min, totals[i]);
                max = Math.max(max, totals[i]);
            }
            values.add(totals.clone());
        }
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextSize(11 * density);
        paint.setStrokeWidth(density);
        for (int tick = 0; tick <= 4; tick++) {
            float y = top + (bottom - top) * tick / 4;
            paint.setColor(0xff303c68);
            canvas.drawLine(left, y, right, y, paint);
            paint.setColor(0xffc9cbe2);
            canvas.drawText(String.format(Locale.ROOT, "%.0f €", max - (max-min)*tick/4), 0, y + 4*density, paint);
        }
        for (int tier = 0; tier < tiers.length; tier++) {
            if(!filter.isEmpty()&&!filter.equals(tiers[tier]))continue;
            Path path = new Path();
            for (int n = 0; n < values.size(); n++) {
                float x = left + (right-left)*n/Math.max(1, values.size()-1);
                float y = bottom - (float)((values.get(n)[tier]-min)/(max-min))*(bottom-top);
                if (n == 0) path.moveTo(x,y); else path.lineTo(x,y);
            }
            paint.setColor(colors[tier]);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth((3-tier*0.5f)*density);
            canvas.drawPath(path,paint);
            paint.setStyle(Paint.Style.FILL);
        }
        paint.setColor(0xffc9cbe2);
        canvas.drawText("0",left,bottom+20*density,paint);
        canvas.drawText((values.size()-1) + " settled signals",left+24*density,bottom+20*density,paint);
    }
}
