package lt.tenisosignalai;

import java.text.DateFormat;
import java.util.*;
import org.json.JSONObject;

final class SignalText {
    static String english(String text) {
        return text.replace("Senas A/B", "Legacy A/B").replace("Žalias", "Green")
                .replace("Geltonas", "Yellow").replace("Rudas", "Brown")
                .replace("Pirmas breikas", "First break").replace("pirmas padavimas", "First serve")
                .replace("Varžovas:", "Opponent:").replace("rezultatas", "Score")
                .replace("reitingų skirtumas", "Ranking gap").replace("atremti breiko taškai", "Break points saved")
                .replace("Dabartinis setas", "Current set").replace("padavimas", "Serve").replace("priėmimas", "Return")
                .replaceAll("(?<=\\d),(?=\\d)", ".");
    }

    static String outcome(JSONObject row) {
        if (row.optJSONObject("bet") == null) return "No pick";
        double profit = row.optDouble("profit", Double.NaN);
        String status = row.optString("betStatus");
        if ("Laimėta".equals(status) && profit > 0) return "Won";
        if ("Pralaimėta".equals(status) && profit < 0) return "Lost";
        if ("Grąžinta".equals(status) && profit == 0) return "Refunded";
        return "Pending";
    }

    static String label(JSONObject bet) {
        return "ml".equals(bet.optString("unit")) ? "ML · Match winner"
                : String.format(Locale.US, "AH %+.1f", bet.optDouble("line"));
    }

    static String quote(JSONObject row) {
        JSONObject bet = row.optJSONObject("bet");
        if (bet == null) return "No published pick";
        return label(bet) + String.format(Locale.US, " @ %.2f · €%.2f model stake", bet.optDouble("odds"), bet.optDouble("stake", 10))
                + " · " + bet.optString("bookmaker", "Unknown bookmaker") + " · " + bet.optString("source")
                + (bet.has("quoted") ? " · Quoted " + DateFormat.getTimeInstance().format(new Date(bet.optLong("quoted"))) : "");
    }

    static String prematch(JSONObject row) {
        JSONObject pre = row.optJSONObject("prematch");
        return pre == null ? "Pre-match odds unavailable" : String.format(Locale.US,
                "Pre-match ML %.2f · %s · %s", pre.optDouble("odds"), pre.optString("bookmaker"), pre.optString("source"));
    }
}
