package lt.tenisosignalai;
import java.util.*;
import org.json.*;
final class SignalPolicy {
    static String key(JSONObject row){return row.optString("date",row.optString("event_date"))+":"+row.optString("id",row.optString("event_key"));}
    static String signalDate(JSONObject row) {
        java.text.SimpleDateFormat fmt=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.ROOT);
        fmt.setTimeZone(TimeZone.getTimeZone("Europe/Vilnius"));
        return fmt.format(new Date(row.optLong("time")));
    }
    static List<JSONObject> filter(List<JSONObject> rows,String date,String tier) {
        List<JSONObject> result=new ArrayList<>();
        for(JSONObject row:rows)if((!tier.isEmpty()||!"legacy".equals(row.optString("tier")))&&(date.isEmpty()||signalDate(row).equals(date))&&(tier.isEmpty()||row.optString("tier").equals(tier)))result.add(row);
        return result;
    }
}
