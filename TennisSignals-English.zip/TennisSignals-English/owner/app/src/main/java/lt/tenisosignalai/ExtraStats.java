package lt.tenisosignalai;

import android.content.SharedPreferences;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

enum ExtraStats {
    TENNIS("Tennis ATP/WTA/ITF","tennis-atp-wta-itf-live-scores-and-point-by-point-stats","/matches/live","items",500),
    OS("OS Sports Perform","os-sports-perform","/v1/events/schedule/live?sport_id=5","data",500),
    SPORT("SportScore","sportscore1","/sports/2/events/live","data",500);

    private static final Pattern RATIO=Pattern.compile("(\\d{1,4})\\s*/\\s*(\\d{1,4})");
    final String label;
    private final String host,path,array;
    private final int limit;
    private long retryAfter;
    private String failedKey="";

    ExtraStats(String label,String host,String path,String array,int limit) {
        this.label=label;this.host=host+".p.rapidapi.com";this.path=path;this.array=array;this.limit=limit;
    }

    JSONArray live(String key,SharedPreferences settings) throws IOException,JSONException {
        JSONArray data=request(path,key,settings).optJSONArray(array);
        if(data==null)throw new IOException(label+" · neatpažintas gyvų mačų sąrašas");
        return data;
    }

    JSONArray statistics(JSONObject match,JSONObject event,String key,SharedPreferences settings) throws IOException,JSONException {
        if(this==TENNIS)return convert(match,event,null);
        String id=event.optString("id");
        if(!id.matches("[0-9]+"))return null;
        String route=this==OS?"/v1/events/statistics?event_id="+id:"/events/"+id+"/statistics";
        return convert(match,event,request(route,key,settings));
    }

    JSONObject find(JSONObject match,JSONArray events) {
        JSONObject found=null;
        for(int i=0;i<events.length();i++) {
            JSONObject event=events.optJSONObject(i);
            if(event==null || orientation(match,event)==0)continue;
            if(found!=null)return null;
            found=event;
        }
        return found;
    }

    private int orientation(JSONObject match,JSONObject event) {
        String date=this==OS?Instant.ofEpochSecond(event.optLong("startTimestamp",0)).atZone(ZoneOffset.UTC).toLocalDate().toString()
                :this==TENNIS?event.optString("started_at"):event.optString("start_at");
        if(date.length()<10 || !date.substring(0,10).equals(match.optString("event_date")))return 0;
        String status=this==OS?object(event,"status").optString("type"):event.optString("status");
        if(!(this==TENNIS?"IN_PROGRESS":"inprogress").equalsIgnoreCase(status))return 0;
        String first=match.optString("event_first_player"), second=match.optString("event_second_player");
        String home=player(event,true),away=player(event,false);
        boolean direct=FlashStats.namesMatch(first,home)&&FlashStats.namesMatch(second,away);
        boolean reverse=FlashStats.namesMatch(first,away)&&FlashStats.namesMatch(second,home);
        int order=direct==reverse?0:direct?1:-1;
        return order!=0 && scoreMatches(match,event,order)?order:0;
    }

    private String player(JSONObject event,boolean home) {
        if(this==TENNIS)return object(event,home?"player1":"player2").optString("name");
        if(this==OS)return object(event,home?"homeTeam":"awayTeam").optString("name");
        JSONObject team=object(event,home?"home_team":"away_team");
        String full=team.optString("name_full","");
        int comma=full.indexOf(", ");
        return comma<0?team.optString("name"):full.substring(comma+2)+" "+full.substring(0,comma);
    }

    private boolean scoreMatches(JSONObject match,JSONObject event,int order) {
        JSONArray scores=match.optJSONArray("scores");
        if(scores==null || scores.length()==0 || scores.length()>5)return false;
        JSONArray sets=event.optJSONArray("sets");
        if(this==TENNIS && (sets==null || sets.length()!=scores.length()))return false;
        String homeKey=this==OS?"homeScore":"home_score",awayKey=this==OS?"awayScore":"away_score";
        for(int i=0;i<scores.length();i++) {
            JSONObject set=scores.optJSONObject(i);
            if(set==null)return false;
            JSONObject external=sets==null?null:sets.optJSONObject(i);
            String period=(this==OS?"period":"period_")+(i+1);
            int home=this==TENNIS?(external==null?-1:external.optInt("player1_games",-1)):object(event,homeKey).optInt(period,-1);
            int away=this==TENNIS?(external==null?-1:external.optInt("player2_games",-1)):object(event,awayKey).optInt(period,-1);
            if(home<0 || away<0 || (order>0?home:away)!=set.optInt("score_first",-1)
                    || (order>0?away:home)!=set.optInt("score_second",-1))return false;
        }
        String next=(this==OS?"period":"period_")+(scores.length()+1);
        return this==TENNIS || (!object(event,homeKey).has(next) && !object(event,awayKey).has(next));
    }

    JSONArray convert(JSONObject match,JSONObject event,JSONObject detail) throws JSONException {
        int order=orientation(match,event);
        if(order==0)return null;
        Map<String,int[]> metrics=new HashMap<>();
        if(this==TENNIS) {
            JSONArray rows=event.optJSONArray("stats");
            if(rows==null)return null;
            for(int i=0;i<rows.length();i++) {
                JSONObject row=rows.optJSONObject(i);
                if(row==null)continue;
                int side=row.optInt("side");
                if(side==1||side==2)metrics.put(row.optString("key")+side,new int[]{row.optInt("numerator",-1),row.optInt("denominator",-1)});
            }
        } else {
            JSONArray rows=detail==null?null:detail.optJSONArray("data");
            if(rows==null)return null;
            for(int i=0;i<rows.length();i++) {
                JSONObject row=rows.optJSONObject(i);
                if(row==null || !"all".equalsIgnoreCase(row.optString("period")))continue;
                if(this==SPORT) {
                    if(row.optLong("event_id",-1)!=event.optLong("id",-2))return null;
                    readRow(metrics,row);
                    continue;
                }
                JSONArray groups=row.optJSONArray("groups");
                if(groups==null)continue;
                for(int j=0;j<groups.length();j++) {
                    JSONObject group=groups.optJSONObject(j);
                    JSONArray items=group==null?null:group.optJSONArray("statisticsItems");
                    if(items==null)continue;
                    for(int k=0;k<items.length();k++) {
                        JSONObject item=items.optJSONObject(k);
                        if(item!=null)readRow(metrics,item);
                    }
                }
            }
        }
        JSONArray result=new JSONArray();
        for(int side=1;side<=2;side++) {
            boolean first=side==(order>0?1:2);
            int games=0,tiebreaks=0;
            JSONArray scores=match.getJSONArray("scores");
            for(int i=0;i<scores.length();i++) {
                JSONObject set=scores.getJSONObject(i);
                int won=set.optInt(first?"score_first":"score_second");
                int lost=set.optInt(first?"score_second":"score_first");
                games+=won;
                if(won==7&&lost==6)tiebreaks++;
            }
            int total=count(metrics,side,"total_games_won","gamesWon");
            if(total<0) {
                int held=count(metrics,side,"service_games_won","serviceGamesWon");
                int broken=count(metrics,side,"break_points_won","breakPointsScored","break_points_converted");
                if(held<0||broken<0)return null;
                total=held+broken+tiebreaks;
            }
            if(total!=games)return null;
            String player=match.optString(first?"first_player_key":"second_player_key");
            int[] serve=metric(metrics,side,"first_serve_points_won","firstServePointsAccuracy");
            if(!valid(serve) || serve[1]==0) {
                int[] returned=metric(metrics,3-side,"first_return_points_won","firstReturnPoints","first_serve_return_points");
                if(!valid(returned)||returned[1]==0)return null;
                serve=new int[]{returned[1]-returned[0],returned[1]};
            }
            if(player.isEmpty())return null;
            add(result,player,"1st serve points won",serve);
            int[] saved=metric(metrics,side,"break_points_saved","breakPointsSaved");
            if(!valid(saved)) {
                int[] converted=metric(metrics,3-side,"break_points_won","breakPointsScored","break_points_converted");
                if(valid(converted))saved=new int[]{converted[1]-converted[0],converted[1]};
            }
            if(valid(saved))add(result,player,"break points saved",saved);
        }
        return result;
    }

    private void readRow(Map<String,int[]> metrics,JSONObject row) {
        String name=row.optString(this==OS?"key":"name");
        for(int side=1;side<=2;side++) {
            String prefix=side==1?"home":"away";
            String value=row.optString(prefix);
            Matcher ratio=RATIO.matcher(value);
            int[] pair=ratio.find()?new int[]{Integer.parseInt(ratio.group(1)),Integer.parseInt(ratio.group(2))}
                    :new int[]{row.optInt(prefix+"Value",row.optInt(prefix,-1)),row.optInt(prefix+"Total",-1)};
            metrics.put(name+side,pair);
        }
    }

    private static JSONObject object(JSONObject value,String key) {
        JSONObject nested=value.optJSONObject(key);
        return nested==null?new JSONObject():nested;
    }

    private static int[] metric(Map<String,int[]> metrics,int side,String... names) {
        for(String name:names) {
            int[] pair=metrics.get(name+side);
            if(pair!=null)return pair;
        }
        return null;
    }

    private static int count(Map<String,int[]> metrics,int side,String... names) {
        int[] pair=metric(metrics,side,names);
        return pair==null?-1:pair[0];
    }

    private static boolean valid(int[] pair) {return pair!=null && pair[0]>=0 && pair[1]>=pair[0];}

    private static void add(JSONArray result,String player,String name,int[] pair) throws JSONException {
        result.put(new JSONObject().put("player_key",player).put("stat_period","match").put("stat_name",name)
                .put("stat_won",pair[0]).put("stat_total",pair[1]));
    }

    private JSONObject request(String route,String key,SharedPreferences settings) throws IOException,JSONException {
        MonitoringWindow.requireBackupAllowed();
        String prefix="extra"+name();
        synchronized(this) {
            long now=System.currentTimeMillis();
            if(now<RapidQuota.blockedUntil(settings,prefix,key) || (key.equals(failedKey)&&now<retryAfter))
                throw new IOException(label+" · kvota arba prieiga pristabdyta");
            String month=YearMonth.now(ZoneId.of("Europe/Vilnius")).toString();
            int used=month.equals(settings.getString(prefix+"Month",""))?settings.getInt(prefix+"Used",0):0;
            if(used>=limit)throw new IOException(label+" · pasiektas vietinis mėnesio limitas");
            if(!settings.edit().putString(prefix+"Month",month).putInt(prefix+"Used",used+1).commit())
                throw new IOException(label+" · nepavyko įrašyti skaitiklio");
        }
        HttpURLConnection connection=(HttpURLConnection)new URL("https://"+host+route).openConnection();
        connection.setConnectTimeout(2500);
        connection.setReadTimeout(2500);
        connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("X-RapidAPI-Host",host);
        connection.setRequestProperty("X-RapidAPI-Key",key);
        try {
            int code=connection.getResponseCode();
            synchronized(this) {
                RapidQuota.observe(connection,settings,prefix,key,System.currentTimeMillis());
                if(code==401||code==403||code==429) {
                    failedKey=key;
                    retryAfter=System.currentTimeMillis()+900000;
                }
            }
            if(code!=200)throw new IOException(label+" · HTTP "+code);
            try(BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream(),StandardCharsets.UTF_8))) {
                StringBuilder body=new StringBuilder();
                char[] buffer=new char[8192];
                int read;
                while((read=reader.read(buffer))!=-1) {
                    MonitoringWindow.requireAllowed();
                    body.append(buffer,0,read);
                }
                return new JSONObject(body.toString());
            }
        } finally {connection.disconnect();}
    }
}
