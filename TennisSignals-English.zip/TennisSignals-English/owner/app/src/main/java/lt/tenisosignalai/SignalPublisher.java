package lt.tenisosignalai;

import android.content.SharedPreferences;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import javax.net.ssl.HttpsURLConnection;
import org.json.*;

final class SignalPublisher {
    private final ScheduledExecutorService worker = Executors.newSingleThreadScheduledExecutor();
    private final SharedPreferences settings;
    private String lastSent = "", lastUrl = "", lastKey = "";
    private long lastSuccess;

    SignalPublisher(SharedPreferences settings) {
        this.settings = settings;
        worker.scheduleWithFixedDelay(this::sync, 0, 10, TimeUnit.SECONDS);
    }

    void close() { worker.shutdownNow(); }

    private void sync() {
        String url = settings.getString("relayUrl", "");
        String key = settings.getString("relayOwnerKey", "");
        if (url.isEmpty() || key.isEmpty() || !settings.getBoolean("creator", false)
                || !settings.getBoolean("monitoringEnabled", false)) return;
        try {
            List<JSONObject> history = new ArrayList<>();
            for (Map.Entry<String, ?> entry : settings.getAll().entrySet()) {
                if (!entry.getKey().startsWith("history:") || !(entry.getValue() instanceof String)) continue;
                try { history.add(new JSONObject((String) entry.getValue())); }
                catch (JSONException ignored) { }
            }
            JSONArray rows = new JSONArray();
            for (JSONObject row : SignalPolicy.filter(SignalPolicy.displayHistory(SignalPolicy.history(history)), "", "")) {
                rows.put(publicRow(row));
            }
            String snapshot = rows.toString();
            long now = System.currentTimeMillis();
            if (url.equals(lastUrl) && key.equals(lastKey) && snapshot.equals(lastSent)
                    && now - lastSuccess < 60000) return;
            byte[] body = new JSONObject().put("schema", 1).put("signals", rows).toString()
                    .getBytes(StandardCharsets.UTF_8);
            if (body.length > RelayHttp.LIMIT) throw new IOException("Feed is too large");
            HttpsURLConnection connection = RelayHttp.open(RelayHttp.base(url), "/v1/feed", key);
            try {
                connection.setRequestMethod("PUT");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setFixedLengthStreamingMode(body.length);
                try (OutputStream out = connection.getOutputStream()) { out.write(body); }
                if (connection.getResponseCode() != 204) throw new IOException("Relay rejected update");
                lastUrl = url;
                lastKey = key;
                lastSent = snapshot;
                lastSuccess = now;
            } finally { connection.disconnect(); }
            if (url.equals(settings.getString("relayUrl", "")) && key.equals(settings.getString("relayOwnerKey", "")))
                settings.edit().putString("relayStatus", "Signalų persiuntimas aktyvus").apply();
        } catch (Exception failure) {
            if (url.equals(settings.getString("relayUrl", "")) && key.equals(settings.getString("relayOwnerKey", "")))
                settings.edit().putString("relayStatus", "Nepavyko persiųsti. Patikrink serverį ir siuntėjo raktą.").apply();
        }
    }

    static JSONObject publicRow(JSONObject row) throws JSONException {
        JSONObject copy = select(row, "id", "date", "tier", "title", "detail", "time", "statsSource",
                "outcome", "betStatus", "profit");
        JSONObject bet = row.optJSONObject("bet");
        if (bet != null) copy.put("bet", select(bet, "unit", "line", "odds", "stake", "bookmaker", "quoted", "source"));
        JSONObject prematch = row.optJSONObject("prematch");
        if (prematch != null) copy.put("prematch", select(prematch, "odds", "bookmaker", "source"));
        return copy;
    }

    private static JSONObject select(JSONObject original, String... keys) throws JSONException {
        JSONObject result = new JSONObject();
        for (String key : keys) if (original.has(key)) result.put(key, original.get(key));
        return result;
    }
}
