package lt.tenisosignalai;

import android.app.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public final class Monitor extends Service {
    private final ScheduledExecutorService worker = Executors.newSingleThreadScheduledExecutor();
    private final Requests requests = new Requests();
    private final ExecutorService preparation = Executors.newSingleThreadExecutor();
    private final ExecutorService maintenance = Executors.newSingleThreadExecutor();
    private Future<Map<String,Integer>> ranksFuture;
    private String ranksToken="";
    private Future<?> settlementFuture;
    private Future<JSONObject> cyclePrimaryOdds;
    private long lastCycle, lastBackup, lastSettlement;
    private final Map<String,QuoteWork> quotes = new HashMap<>();
    private final Map<String,Future<JSONObject>> cycleSecondaryOdds = new HashMap<>();
    private static final class QuoteWork {
        final Future<JSONObject> pre;
        final long deadline;
        QuoteWork(Future<JSONObject> pre,long deadline){this.pre=pre;this.deadline=deadline;}
    }
    private final Map<String, String> playerCountries = new HashMap<>();
    private final Map<String, Future<String>> countryRequests = new HashMap<>();
    private final Map<String, Long> countryRetryAfter = new HashMap<>();
    private final Map<String, Integer> ranks = new HashMap<>();
    private final BackupStats backup = new BackupStats();
    private final SecondaryOdds secondaryOdds = new SecondaryOdds(backup);
    private NotificationManager notifications;
    private SharedPreferences settings;
    private SignalPublisher publisher;
    private volatile String key = "";
    private String cachedKey = "";
    private long ranksTime, lastRanksAttempt;
    private boolean scheduled;

    @Override public void onCreate() {
        super.onCreate();
        settings = getSharedPreferences("monitor", MODE_PRIVATE);
        migrateMatchLocks();
        publisher = new SignalPublisher(settings);
        backup.setBudget(settings);
        backup.setRequests(requests);
        notifications = getSystemService(NotificationManager.class);
        notifications.createNotificationChannel(new NotificationChannel("monitor", "Stebėjimas", NotificationManager.IMPORTANCE_LOW));
        notifications.createNotificationChannel(new NotificationChannel("signals", "Teniso signalai", NotificationManager.IMPORTANCE_HIGH));
    }

    @Override public int onStartCommand(Intent intent, int flags, int id) {
        key = settings.getString("key", "");
        startForeground(1, notification("monitor", "Teniso signalai", "Jungiamasi prie API Tennis").setOngoing(true).build());
        if (!scheduled) {
            scheduled = true;
            worker.scheduleAtFixedRate(this::check, 0, 10, TimeUnit.SECONDS);
        }
        return START_NOT_STICKY;
    }

    private Notification.Builder notification(String channel, String title, String body) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, channel).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title).setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body)).setContentIntent(open);
    }

    private JSONArray fetch(String query, String token) throws Exception {
        return fetchResponse(query, token).getJSONArray("result");
    }

    private JSONObject fetchResponse(String query, String token) throws Exception {
        MonitoringWindow.requireAllowed();
        String url = "https://api.api-tennis.com/tennis/?method=" + query
                + "&APIkey=" + URLEncoder.encode(token, "UTF-8");
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setConnectTimeout(4000);
        connection.setReadTimeout(4000);
        connection.setInstanceFollowRedirects(false);
        try {
            int status = connection.getResponseCode();
            if (status != 200) throw new IOException("HTTP " + status);
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder body = new StringBuilder();
                char[] buffer=new char[8192];int read;
                while((read=reader.read(buffer))!=-1) {
                    if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Užklausa sustabdyta");
                    body.append(buffer,0,read);
                }
                JSONObject response = new JSONObject(body.toString());
                if (response.optInt("success") != 1) throw new IOException("API užklausa atmesta");
                return response;
            }
        } finally {
            connection.disconnect();
        }
    }

    private void check() {
        if (!MonitoringWindow.allowed() || !settings.getBoolean("monitoringEnabled", false)) {
            if (!worker.isShutdown()) notifications.notify(1, notification("monitor", "Teniso signalai",
                    "Stebėjimas sustabdytas").setOngoing(true).build());
            return;
        }
        String token = key;
        String status;
        try {
            long started=System.currentTimeMillis();
            if(started-lastCycle<9000)return; // No catch-up burst after a slow cycle.
            lastCycle=started;
            quotes.clear();
            cycleSecondaryOdds.clear();
            Future<JSONObject> liveRequest=requests.submit(()->{
                JSONObject data=fetchResponse("get_livescore",token);
                return data.put("_received",System.currentTimeMillis());
            });
            cyclePrimaryOdds=null;
            refreshRanks(token);
            JSONObject board=Requests.await(liveRequest,Requests.deadline(4500));
            if(board==null){liveRequest.cancel(true);throw new IOException("Gyvi mačai neatsakė laiku");}
            JSONArray matches=board.getJSONArray("result");
            long statsReceived=board.getLong("_received");
            refreshRanks(token);
            List<JSONObject> missing = new ArrayList<>();
            for (int i = 0; i < matches.length(); i++) {
                JSONObject match = matches.optJSONObject(i);
                if (match == null || !"1".equals(match.optString("event_live"))
                        || !match.optString("event_status").matches("(?i)set [1-5]")
                        || !match.optString("event_type_type").toLowerCase(Locale.ROOT).contains("singles")) continue;
                String id = match.optString("event_key");
                String firstCountry = playerCountry(match.optString("first_player_key"));
                String secondCountry = playerCountry(match.optString("second_player_key"));
                if (firstCountry.isEmpty() || secondCountry.isEmpty()) {
                    match.put("_countryStatus", "pending");
                    continue;
                }
                if (firstCountry.equals(secondCountry)) {
                    match.put("_countryStatus", "blocked");
                    continue;
                }
                if (!settings.getBoolean("creator", false)
                        && !settings.getStringSet("selected", Collections.emptySet()).contains(id)) continue;
                match.put("_statsReceived",statsReceived);
                if (needsBackupStats(match)) missing.add(match);
            }
            Future<?> statsWork=null;
            long statsDeadline=Requests.deadline(7000);
            if(!missing.isEmpty() && started-lastBackup>=30000) {
                lastBackup=started;
                List<JSONObject> snapshotMissing=new ArrayList<>();
                for(JSONObject m:missing)snapshotMissing.add(new JSONObject(m.toString()));
                String secondaryKey=settings.getString("backupKey", "").trim();
                statsWork=preparation.submit(()->backup.prepare(snapshotMissing,secondaryKey));
            }
            // Launch candidate requests for all ready matches before waiting on any one match.
            for(int i=0;i<matches.length();i++) {
                JSONObject match=matches.optJSONObject(i);
                if(match!=null&&match.has("_statsReceived")&&hasServePair(match))evaluate(match,true);
            }
            int count = 0;
            JSONArray live = new JSONArray();
            Set<String> active = new HashSet<>();
            for (int i = 0; i < matches.length(); i++) {
                JSONObject match = matches.optJSONObject(i);
                if (match == null || !"1".equals(match.optString("event_live"))
                        || !match.optString("event_status").matches("(?i)set [1-5]")
                        || !match.optString("event_type_type").toLowerCase(Locale.ROOT).contains("singles")) continue;
                count++;
                String event = match.optString("event_key");
                active.add(event);
                live.put(new JSONObject().put("id", event).put("label",
                        match.optString("event_first_player") + " – "
                        + match.optString("event_second_player") + "\n" + match.optString("tournament_name"))
                        .put("countryStatus", match.optString("_countryStatus")));
                if (match.has("_statsReceived") && hasServePair(match)) evaluate(match);
            }
            settings.edit().putString("live", live.toString()).apply();
            if(statsWork!=null){Requests.await(statsWork,statsDeadline);if(!statsWork.isDone())statsWork.cancel(true);}
            settings.edit().putString("backupStatus", !MonitoringWindow.workingTime(System.currentTimeMillis())
                    ? "API Tennis veikia · Matchstat tik 10:00–22:00 Lietuvos laiku"
                    : missing.isEmpty()?"Nėra mačų, kuriems reikia Matchstat patikros":backup.status).apply();
            for(JSONObject match:missing)if(backup.get(match)!=null)evaluate(match,true);
            for(JSONObject match:missing)if(!hasServePair(match)||backup.get(match)!=null)evaluate(match);
            if(started-lastSettlement>=60000 && (settlementFuture==null||settlementFuture.isDone())) {
                lastSettlement=started;
                Set<String> activeSnapshot=new HashSet<>(active);
                settlementFuture=maintenance.submit(()->settle(activeSnapshot,token));
            }
            status = "Gyvų vienetų mačų: " + count + " · ciklas kas 10 s · AH iki 30 s";
        } catch (Exception failure) {
            status = "Duomenys nepasiekiami. Patikrink ryšį ir API prieigą.";
        }
        for(QuoteWork work:quotes.values())if(!work.pre.isDone())work.pre.cancel(true);
        for(Future<JSONObject> future:cycleSecondaryOdds.values())if(!future.isDone())future.cancel(true);
        if(cyclePrimaryOdds!=null&&!cyclePrimaryOdds.isDone())cyclePrimaryOdds.cancel(true);
        if (!worker.isShutdown()) {
            notifications.notify(1, notification("monitor", "Teniso signalai", status).setOngoing(true).build());
        }
    }

    private void evaluate(JSONObject match) {evaluate(match,false);}
    private void evaluate(JSONObject match,boolean prepareOnly) {
        JSONArray scores = match.optJSONArray("scores");
        JSONArray stats = match.optJSONArray("statistics");
        String event = match.optString("event_key");
        if (scores == null || event.isEmpty()) return;
        settings.edit().remove("ahPending:" + event).apply();
        String source = "API Tennis";
        long captured = match.optLong("_statsReceived",System.currentTimeMillis());
        if (!primaryReady(match)) {
            JSONObject alternate = backup.get(match);
            if (alternate != null) {
                stats = alternate.optJSONArray("statistics");
                source = alternate.optString("source");
                captured = alternate.optLong("captured");
            }
        }
        settings.edit().putString("source:" + event, "Statistika · " + source
                + (stats == null || stats.length() == 0 ? " · duomenų nėra" : "")).apply();
        if (stats == null) stats = new JSONArray();
        try { match.put("statsSource", source).put("statsCaptured", captured); }
        catch (JSONException invalid) { return; }
        int games = 0;
        StringJoiner score = new StringJoiner(", ");
        for (int i = 0; i < scores.length(); i++) {
            JSONObject set = scores.optJSONObject(i);
            if (set == null) return;
            int first = set.optInt("score_first", -1);
            int second = set.optInt("score_second", -1);
            if (first < 0 || second < 0 || first > 7 || second > 7) return;
            games += first + second;
            score.add(first + ":" + second);
        }
        String firstBreaker = firstBreaker(match.optJSONArray("pointbypoint"));
        String cReason = firstBreaker.isEmpty() ? "C · trūksta pilnos geimų sekos arba pirmo breiko dar nėra" : "C · pirmas breikas užfiksuotas";
        if(settings.contains("matchLock:"+SignalPolicy.key(match)))return;
        GreenSet greenSet = games >= 5 ? GreenSet.read(match, scores) : null;
        List<JSONObject> proposals=new ArrayList<>();
        boolean candidate=false;
        for(String side:new String[]{"first","second"}) {
            String other=side.equals("first")?"second":"first";
            String player=match.optString(side+"_player_key"), opponent=match.optString(other+"_player_key");
            int[] served=serve(stats,player), received=serve(stats,opponent), saved=statistic(stats,player,"break points saved");
            if(served==null)continue;
            String tag="sent:"+event+":"+player;
            boolean sideCandidate=false;
            if(!settings.contains(tag) && games>=5) {
                sideCandidate |= received!=null && Rule.matchesA(games,ranks.getOrDefault(player,0),ranks.getOrDefault(opponent,0),
                        served[0],served[1],received[0],received[1],900,70);
                sideCandidate |= greenB(greenSet, side, games, served, saved);
            }
            sideCandidate |= !settings.contains(tag+":C") && side.equals(firstBreaker) && Rule.matchesC(games,true,served[0],served[1],1.40);
            if(sideCandidate)candidate=true;
        }
        if (candidate) prefetchOdds(match);
        if(prepareOnly)return;
        for (String side : new String[]{"first", "second"}) {
            String other = side.equals("first") ? "second" : "first";
            String player = match.optString(side + "_player_key");
            String opponent = match.optString(other + "_player_key");
            int rank = ranks.getOrDefault(player, 0);
            int otherRank = ranks.getOrDefault(opponent, 0);
            int[] serve = serve(stats, player);
            int[] otherServe = serve(stats, opponent);
            String tag = "sent:" + event + ":" + player;
            if (worker.isShutdown()) continue;
            if (serve == null) {
                if (side.equals(firstBreaker)) settings.edit().putString("c:" + event, "C · trūksta pirmo padavimo statistikos").apply();
                continue;
            }
            if (side.equals(firstBreaker)) cReason = settings.contains(tag + ":C") ? "C · signalas jau išsiųstas"
                    : "C · pirmas breikas yra · pirmas padavimas " + (serve[1] > 0 ? format(serve) : "duomenų nėra") + " · reikia ≥68 %";
            if (games < 4) cReason = "C · reikia bent 4 užbaigtų geimų (dabar " + games + ")";
            String cTag = tag + ":C";
            if (games >= 4 && side.equals(firstBreaker) && !settings.contains(cTag)
                    && serve[1] > 0 && serve[0] >= 0 && serve[0] <= serve[1]
                    && serve[0] * 100L >= serve[1] * 68L) {
                double cOdds = prematchOdds(match, side);
                cReason = Double.isNaN(cOdds) ? "C · nėra prematch koeficiento abiejuose šaltiniuose"
                        : "C · prematch " + cOdds + (Rule.prematch(cOdds) ? " · sąlygos atitinka" : " · už 1,10–2,20 ribų");
                if (Rule.matchesC(games,true, serve[0], serve[1], cOdds)) {
                    propose(proposals, player, cTag, "yellow", "🟡 Geltonas C: "
                            + match.optString("event_" + side + "_player"),
                            "Pirmas breikas · " + score + " · pirmas padavimas " + format(serve)
                                    + " · prematch " + cOdds);
                }
            }
            settings.edit().putString("c:" + event, cReason).apply();
            if (games < 5 || settings.contains(tag)) continue;
            boolean ruleA = otherServe != null && Rule.matches(games, rank, otherRank,
                    serve[0], serve[1], otherServe[0], otherServe[1]);
            int[] saved = statistic(stats, player, "break points saved");
            boolean ruleB = greenB(greenSet, side, games, serve, saved);
            if ((ruleA || ruleB) && !Rule.prematch(prematchOdds(match, side))) continue;
            if (!ruleA && !ruleB) continue;
            String rule = ruleA && ruleB ? "A + B" : ruleA ? "A" : "B";
            String title = "🟢 Žalias " + rule + ": "
                    + match.optString("event_" + side + "_player");
            int selected = side.equals("first") ? 0 : 1;
            String body = "Varžovas: " + match.optString("event_" + other + "_player")
                    + " · rezultatas " + greenScore(scores, selected) + " · pirmas padavimas " + format(serve)
                    + (ruleA ? " / " + format(otherServe) + " · reitingų skirtumas "
                        + Math.abs(rank - otherRank) : "")
                    + (ruleB ? " · atremti breiko taškai " + format(saved)
                        + "\nDabartinis setas · padavimas " + format(greenSet.serve(selected))
                        + " / " + format(greenSet.serve(1 - selected))
                        + " · priėmimas " + format(greenSet.receive(selected))
                        + " / " + format(greenSet.receive(1 - selected)) : "");
            propose(proposals, player, tag, "green", title, body);
        }
        JSONObject best=SignalPolicy.strongest(proposals);
        if(candidate && best!=null)record(match,best.optString("player"),best.optString("tag"),best.optString("tier"),best.optString("title"),best.optString("body"));
    }

    static boolean greenB(GreenSet set, String side, int games, int[] serve, int[] saved) {
        return set != null && saved != null && set.leads(side.equals("first") ? 0 : 1)
                && Rule.matchesB(games, serve[0], serve[1], saved[0], saved[1], 1.40);
    }

    static String greenScore(JSONArray scores, int side) {
        StringJoiner result = new StringJoiner(", ");
        for (int i = 0; i < scores.length(); i++) {
            JSONObject set = scores.optJSONObject(i);
            int first = set.optInt("score_first"), second = set.optInt("score_second");
            result.add(side == 0 ? first + ":" + second : second + ":" + first);
        }
        return result.toString();
    }

    private void propose(List<JSONObject> candidates,String player,String tag,String tier,String title,String body) {
        try{candidates.add(new JSONObject().put("player",player).put("tag",tag).put("tier",tier).put("title",title).put("body",body));}
        catch(JSONException ignored){}
    }
    private void migrateMatchLocks() {
        List<JSONObject> rows=new ArrayList<>();
        for(Map.Entry<String,?> entry:settings.getAll().entrySet())if(entry.getKey().startsWith("history:")) {
            try{rows.add(new JSONObject((String)entry.getValue()));}catch(Exception ignored){}
        }
        SharedPreferences.Editor edit=settings.edit();
        for(JSONObject row:SignalPolicy.history(rows)) {
            String lock="matchLock:"+SignalPolicy.key(row);
            if(!settings.contains(lock))edit.putString(lock,row.optString("player"));
        }
        edit.apply();
    }

    private void record(JSONObject match, String player, String tag,
                        String tier, String title, String body) {
        if (!MonitoringWindow.allowed() || worker.isShutdown() || !settings.getBoolean("monitoringEnabled",false)) return;
        String lock="matchLock:"+SignalPolicy.key(match);
        if(settings.contains(lock))return;
        String historyTag="sent:match:"+SignalPolicy.key(match);
        JSONObject row = new JSONObject();
        long now = System.currentTimeMillis();
        try {
            String playerSide = player.equals(match.optString("first_player_key")) ? "first" : "second";
            if (player.isEmpty() || !player.equals(match.optString(playerSide + "_player_key"))) return;
            double preOdds = prematchOdds(match, playerSide);
            if (!Rule.prematch(preOdds)) return;
            JSONObject pre = match.optJSONObject("prematch:" + playerSide);
            if (pre != null) row.put("prematch", new JSONObject(pre.toString()));
            else row.put("prematchReason", match.optString("prematchReason", "Prematch nepasiekiamas"));
            JSONObject bet = liveBet(match, player, "green".equals(tier));
            row.put("ahReason", match.optString("ahReason"));
            JSONObject rawAH = match.optJSONObject("unverifiedAH");
            if (rawAH != null) row.put("unverifiedAH", new JSONObject(rawAH.toString()));
            now = System.currentTimeMillis();
            if (!Bet.ready(bet, now) || !SignalTiming.ready(match.optLong("statsCaptured"),bet==null?0:bet.optLong("received"),now)) {
                settings.edit().putString("ahPending:" + match.optString("event_key"),
                        "AH / ML laukiama · " + match.optString("event_" + playerSide + "_player") + " · "
                        + (Bet.ready(bet,now)?"Statistikos ir AH gavimo laikai per toli; laukiama naujos patikros":match.optString("ahReason", "Nėra gyvos AH / ML 1,35–2,20"))).apply();
                return; // Do not mark sent or record a signal without its contemporaneous AH quote.
            }
            settings.edit().remove("ahPending:" + match.optString("event_key")).apply();
            row.put("betStatus", "Vyksta").put("bet", bet);
            if (!MonitoringWindow.allowed() || worker.isShutdown() || !settings.getBoolean("monitoringEnabled",false)) return;
            row.put("policyVersion",21).put("id", match.optString("event_key")).put("date", match.optString("event_date"))
                    .put("tier", tier).put("player", player).put("title", title).put("detail", body)
                    .put("time", now).put("outcome", "Vyksta")
                    .put("statsAgeAtSignalMs",now-match.optLong("statsCaptured"))
                    .put("quoteAgeAtSignalMs",now-bet.optLong("quoted"))
                    .put("receiptGapMs",Math.abs(match.optLong("statsCaptured")-bet.optLong("received")))
                    .put("statsSource", match.optString("statsSource", "API Tennis"))
                    .put("statsCaptured", match.optLong("statsCaptured", now));
            body += "\nStatistika · " + row.optString("statsSource");
            body += "\n" + Odds.prematchSummary(row);
            body += "\n" + Bet.summary(row);
        } catch (JSONException invalid) {
            return;
        }
        if(settings.contains(lock))return;
        settings.edit().putString(lock,player).putLong(tag,now).putLong(historyTag, now)
                .putString("history:" + historyTag, row.toString()).apply();
        if (notifications.areNotificationsEnabled()) {
            notifications.notify(historyTag, 2, notification("signals", title, body).setAutoCancel(true).build());
        }
    }

    static String firstBreaker(JSONArray games) {
        if (games == null) return "";
        int set = 1, number = 1, first = 0, second = 0;
        for (int i = 0; i < games.length(); i++) {
            JSONObject game = games.optJSONObject(i);
            if (game == null || !("Set " + set).equalsIgnoreCase(game.optString("set_number"))
                    || game.optInt("number_game") != number) return "";
            String[] score = game.optString("score").split("\\s*-\\s*");
            if (score.length != 2 || !score[0].matches("[0-7]") || !score[1].matches("[0-7]")) return "";
            int nextFirst = Integer.parseInt(score[0]);
            int nextSecond = Integer.parseInt(score[1]);
            boolean firstWon = nextFirst == first + 1 && nextSecond == second;
            boolean secondWon = nextSecond == second + 1 && nextFirst == first;
            if (!firstWon && !secondWon) return "";
            if (first != 6 || second != 6) {
                String server = game.optString("player_served");
                if (!server.equals("First Player") && !server.equals("Second Player")) return "";
                if (firstWon && server.equals("Second Player")) return "first";
                if (secondWon && server.equals("First Player")) return "second";
            }
            first = nextFirst;
            second = nextSecond;
            number++;
            if (Math.max(first, second) == 7 || (Math.max(first, second) == 6
                    && Math.abs(first - second) >= 2)) {
                set++;
                number = 1;
                first = second = 0;
            }
        }
        return "";
    }

    private final Map<String, Long> resultChecks = new HashMap<>();

    private void settle(Set<String> active, String token) {
        for (Map.Entry<String, ?> entry : settings.getAll().entrySet()) {
            if (!entry.getKey().startsWith("history:")) continue;
            try {
                JSONObject row = new JSONObject((String) entry.getValue());
                String id = row.getString("id");
                String date = row.getString("date");
                if ((!"Vyksta".equals(row.getString("outcome"))
                        && !(row.has("bet") && !row.has("profit"))) || active.contains(id)
                        || !id.matches("[0-9]+") || !date.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) continue;
                long now = System.currentTimeMillis();
                if (now - resultChecks.getOrDefault(id, 0L) >= 300000L) {
                    resultChecks.put(id, now);
                    JSONArray rows = fetch("get_fixtures&match_key=" + id
                            + "&date_start=" + date + "&date_stop=" + date, token);
                    for (int i = 0; i < rows.length(); i++) {
                        JSONObject match = rows.getJSONObject(i);
                        if (!id.equals(match.optString("event_key"))) continue;
                        String outcome = outcome(match, row.getString("player"));
                        if (outcome != null) {
                            row.put("outcome", outcome);
                            Bet.settle(row, match);
                            for (Map.Entry<String, ?> history : settings.getAll().entrySet()) {
                                if (!history.getKey().startsWith("history:")) continue;
                                JSONObject related = new JSONObject((String) history.getValue());
                                if (!id.equals(related.optString("id")) || (!"Vyksta".equals(related.optString("outcome"))
                                        && !(related.has("bet") && !related.has("profit")))) continue;
                                String relatedOutcome = outcome(match, related.optString("player"));
                                if (relatedOutcome == null) continue;
                                related.put("outcome", relatedOutcome);
                                Bet.settle(related, match);
                                settings.edit().putString(history.getKey(), related.toString()).apply();
                            }
                            resultChecks.remove(id);
                        }
                    }
                }
                // Check at most one disappeared match per polling cycle.
                if (resultChecks.getOrDefault(id, 0L) == now || !"Vyksta".equals(row.optString("outcome"))) return;
            } catch (Exception unavailable) {
                return;
            }
        }
    }

    private String outcome(JSONObject match, String player) {
        String status = match.optString("event_status").toLowerCase(Locale.ROOT);
        if (status.matches("retired|cancelled|canceled|walkover|abandoned")) return "Nutraukta";
        if (!status.equals("finished")) return null;
        String winner = match.optString("event_winner");
        String side = winner.equals("First Player") ? "first"
                : winner.equals("Second Player") ? "second" : "";
        if (side.isEmpty()) return null;
        String winnerKey = match.optString(side + "_player_key");
        if (winnerKey.isEmpty() || !(player.equals(match.optString("first_player_key"))
                || player.equals(match.optString("second_player_key")))) return null;
        return player.equals(winnerKey) ? "Laimėta" : "Pralaimėta";
    }

    private void refreshRanks(String token) {
        if(ranksFuture!=null && ranksFuture.isDone()) {
            Map<String,Integer> loaded=Requests.await(ranksFuture,Requests.deadline(0));
            if(loaded!=null && token.equals(ranksToken)){ranks.clear();ranks.putAll(loaded);ranksTime=System.currentTimeMillis();cachedKey=token;}
            ranksFuture=null;
        }
        long now=System.currentTimeMillis();
        if(ranksFuture==null && (!token.equals(ranksToken)||now-lastRanksAttempt>=60000)
                && (!token.equals(cachedKey)||now-ranksTime>=21600000L)) {
            lastRanksAttempt=now;
            ranksToken=token;
            ranksFuture=requests.submit(()->{
                Map<String,Integer> updated=new HashMap<>();
                for(String tour:new String[]{"ATP","WTA"}) {
                    JSONArray rows=fetch("get_standings&event_type="+tour,token);
                    for(int i=0;i<rows.length();i++){JSONObject r=rows.getJSONObject(i);updated.put(r.getString("player_key"),r.optInt("place"));}
                }
                return updated;
            });
        }
    }
    private String playerCountry(String player) {
        if (!player.matches("[0-9]+")) return "";
        String known = playerCountries.get(player);
        if (known != null) return known;

        Future<String> pending = countryRequests.get(player);
        if (pending != null) {
            if (!pending.isDone()) return "";
            countryRequests.remove(player);
            String country = Requests.await(pending, Requests.deadline(0));
            if (country != null && !country.isEmpty()) {
                playerCountries.put(player, country);
                countryRetryAfter.remove(player);
                return country;
            }
        }

        long now = System.currentTimeMillis();
        if (now < countryRetryAfter.getOrDefault(player, 0L)) return "";
        countryRetryAfter.put(player, now + 60000L);
        String token = key;
        countryRequests.put(player, requests.submit(() -> {
            JSONArray profiles = fetch("get_players&player_key=" + player, token);
            for (int i = 0; i < profiles.length(); i++) {
                JSONObject profile = profiles.optJSONObject(i);
                if (profile == null || !player.equals(profile.optString("player_key"))) continue;
                if (profile.isNull("player_country")) return "";
                String country = profile.optString("player_country").trim()
                        .replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
                if (Arrays.asList("-", "unknown", "n/a", "null").contains(country)) return "";
                return country;
            }
            return "";
        }));
        return "";
    }

    private boolean hasServePair(JSONObject match) {
        JSONArray stats=match.optJSONArray("statistics");
        if(stats==null)return false;
        for(String side:new String[]{"first","second"}) {
            int[] value=serve(stats,match.optString(side+"_player_key"));
            if(value==null||value[1]<=0||value[0]<0||value[0]>value[1])return false;
        }
        return true;
    }
    private QuoteWork prefetchOdds(JSONObject match) {
        String id=SignalPolicy.key(match);
        QuoteWork existing=quotes.get(id);
        if(existing!=null)return existing;
        try {
            JSONObject snapshot=new JSONObject(match.toString());
            String primaryKey=key, secondaryKey=settings.getString("backupKey","").trim();
            if (cyclePrimaryOdds==null) {
                cyclePrimaryOdds=requests.submit(()->{
                    JSONObject data=fetchResponse("get_live_odds&timezone=UTC",primaryKey);
                    return data.put("_received",System.currentTimeMillis());
                });
            }
            long deadline=Requests.deadline(3000);
            Future<JSONObject> pre=requests.submit(()->loadPrematchQuote(snapshot,primaryKey,secondaryKey));
            QuoteWork work=new QuoteWork(pre,deadline);
            quotes.put(id,work);
            return work;
        }catch(JSONException invalid){return null;}
    }

    private JSONObject liveBet(JSONObject match,String player,boolean green) throws JSONException {
        QuoteWork work=prefetchOdds(match);
        JSONObject payload=work==null?null:Requests.await(cyclePrimaryOdds,work.deadline);
        JSONObject markets=payload==null?null:payload.optJSONObject("result");
        JSONObject event=markets==null?null:markets.optJSONObject(match.optString("event_key"));
        boolean primaryUsable=event!=null && match.optString("event_date").equals(event.optString("event_date"))
                && match.optString("first_player_key").equals(event.optString("first_player_key"))
                && match.optString("second_player_key").equals(event.optString("second_player_key"));
        boolean first=player.equals(match.optString("first_player_key"));
        String side=first?"first":"second";
        JSONObject pre=match.optJSONObject("prematch:"+side);
        double prematch=pre==null?Double.NaN:pre.optDouble("odds",Double.NaN);
        JSONObject result=null;
        match.put("ahReason","API Tennis: nėra šviežios tinkamos AH / ML kainos");
        if(primaryUsable && SignalTiming.ready(match.optLong("statsCaptured"),payload.optLong("_received"),System.currentTimeMillis())) {
            JSONArray offers=Bet.primaryOffers(event.optJSONArray("live_odds"),first?"1":"2",System.currentTimeMillis());
            result=Bet.choose(offers,prematch,System.currentTimeMillis(),green);
            if(result!=null) {
                result.put("received",payload.optLong("_received"));
                match.put("ahReason","API Tennis: AH / ML gauta");
            }
        }
        if (result==null && MonitoringWindow.backupAllowed()
                && System.currentTimeMillis()-match.optLong("statsCaptured")<SignalTiming.MAX_RECEIPT_GAP) {
            String secondaryKey=settings.getString("backupKey","").trim();
            String lookup=SignalPolicy.key(match)+":"+BackupStats.scoreKey(match);
            Future<JSONObject> fallback=cycleSecondaryOdds.computeIfAbsent(lookup,
                    ignored->requests.submit(()->secondaryOdds.bothLive(match,secondaryKey)));
            long remaining=SignalTiming.MAX_RECEIPT_GAP-(System.currentTimeMillis()-match.optLong("statsCaptured"));
            JSONObject alternate=Requests.await(fallback,Requests.deadline(Math.min(2500,Math.max(0,remaining))));
            if(!fallback.isDone())fallback.cancel(true);
            JSONObject sideOdds=alternate==null?null:alternate.optJSONObject(side);
            if(sideOdds!=null) {
                match.put("ahReason",sideOdds.optString("reason"));
                if(sideOdds.has("unverifiedAH"))match.put("unverifiedAH",sideOdds.getJSONObject("unverifiedAH"));
                result=Bet.choose(sideOdds.optJSONArray("offers"),prematch,System.currentTimeMillis(),green);
                if(result!=null&&!SignalTiming.ready(match.optLong("statsCaptured"),result.optLong("received"),System.currentTimeMillis()))result=null;
            }
        }
        return result;
    }
    private final Map<String,JSONObject> oddsCache=new ConcurrentHashMap<>();
    private final Map<String,Long> preFailed=new ConcurrentHashMap<>();
    private JSONObject loadPrematchQuote(JSONObject match,String token,String secondaryKey) {
        String event=match.optString("event_key")+":"+match.optString("event_date");
        JSONObject quote=oddsCache.get(event);
        long now=System.currentTimeMillis();
        if(quote!=null)return quote;
        if(now-preFailed.getOrDefault(event,0L)<60000)return null;
        try {
            String id=match.optString("event_key");
            if(id.matches("[0-9]+")) {
                JSONObject result=fetchResponse("get_odds&match_key="+id,token).optJSONObject("result");
                JSONObject odds=result==null?null:result.optJSONObject(id);
                quote=Odds.prematchPrimary(odds==null?null:odds.optJSONObject("Home/Away"),System.currentTimeMillis());
            }
        }catch(Exception ignored){}
        if(quote==null && !Thread.currentThread().isInterrupted())quote=secondaryOdds.prematch(match,secondaryKey);
        if(Thread.currentThread().isInterrupted())return null;
        if(quote!=null){if(oddsCache.size()>256)oddsCache.clear();oddsCache.put(event,quote);}else preFailed.put(event,now);
        return quote;
    }
    private double prematchOdds(JSONObject match,String side) {
        QuoteWork work=prefetchOdds(match);
        JSONObject quote=work==null?null:Requests.await(work.pre,work.deadline);
        try {
            if(quote==null){match.put("prematchReason","Prematch neatsakė laiku arba kaina neprieinama");return Double.NaN;}
            double value=quote.optDouble(side.equals("first")?"first":"second",Double.NaN);
            match.put("prematch:"+side,new JSONObject(quote.toString()).put("odds",value).put("side",side));
            return value;
        }catch(JSONException invalid){return Double.NaN;}
    }

    private boolean needsBackupStats(JSONObject match) {
        if (primaryReady(match) || settings.contains("matchLock:"+SignalPolicy.key(match))) return false;
        JSONArray scores=match.optJSONArray("scores");
        if (scores==null || scores.length()==0) return false;
        int games=0;
        for (int i=0;i<scores.length();i++) {
            JSONObject set=scores.optJSONObject(i);
            if (set==null) return false;
            int first=set.optInt("score_first",-1), second=set.optInt("score_second",-1);
            if (first<0 || first>7 || second<0 || second>7) return false;
            games+=first+second;
        }
        if(!hasServePair(match))return games>=5
                || (games==4 && !firstBreaker(match.optJSONArray("pointbypoint")).isEmpty());
        if(games<5)return false;
        JSONArray stats=match.optJSONArray("statistics");
        for(String side:new String[]{"first","second"}) {
            String player=match.optString(side+"_player_key");
            int[] serve=serve(stats,player);
            int[] saved=statistic(stats,player,"break points saved");
            if(serve[0]*100L>=serve[1]*55L
                    && (saved==null || saved[1]<0 || saved[0]<0 || saved[0]>saved[1])) return true;
        }
        return false;
    }

    private boolean primaryReady(JSONObject match) {
        JSONArray stats = match.optJSONArray("statistics");
        if (stats == null) return false;
        for (String side : new String[]{"first", "second"}) {
            String player = match.optString(side + "_player_key");
            int[] serve = serve(stats, player);
            int[] saved = statistic(stats, player, "break points saved");
            if (serve == null || serve[1] <= 0 || serve[0] < 0 || serve[0] > serve[1]
                    || saved == null || saved[1] < 0 || saved[0] < 0 || saved[0] > saved[1]) return false;
        }
        return true;
    }

    private int[] serve(JSONArray stats, String player) {
        return statistic(stats, player, "1st serve points won");
    }

    private int[] statistic(JSONArray stats, String player, String name) {
        for (int i = 0; i < stats.length(); i++) {
            JSONObject row = stats.optJSONObject(i);
            if (row != null && player.equals(row.optString("player_key"))
                    && "match".equalsIgnoreCase(row.optString("stat_period"))
                    && name.equalsIgnoreCase(row.optString("stat_name").trim())) {
                return new int[]{row.optInt("stat_won", -1), row.optInt("stat_total", -1)};
            }
        }
        return null;
    }

    private String format(int[] stats) {
        return String.format(Locale.forLanguageTag("lt"), "%d/%d (%.1f %%)",
                stats[0], stats[1], 100.0 * stats[0] / stats[1]);
    }

    @Override public void onTimeout(int startId, int type) { stopSelf(); }
    @Override public void onDestroy() {
        publisher.close();
        worker.shutdownNow();preparation.shutdownNow();requests.close();maintenance.shutdownNow();
        settings.edit().remove("live").apply();super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
