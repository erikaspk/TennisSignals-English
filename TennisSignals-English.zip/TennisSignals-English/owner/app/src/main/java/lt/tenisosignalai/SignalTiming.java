package lt.tenisosignalai;
final class SignalTiming {
    static final long MAX_STATS_AGE=10000, MAX_RECEIPT_GAP=5000;
    static boolean ready(long statsReceived,long oddsReceived,long now) {
        return statsReceived>0 && oddsReceived>0 && now>=statsReceived && now>=oddsReceived
                && now-statsReceived<=MAX_STATS_AGE && now-oddsReceived<=MAX_STATS_AGE
                && Math.abs(statsReceived-oddsReceived)<=MAX_RECEIPT_GAP;
    }
}
