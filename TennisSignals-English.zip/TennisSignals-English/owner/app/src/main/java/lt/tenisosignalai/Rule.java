package lt.tenisosignalai;

final class Rule {
    static boolean prematch(double odds) {return Double.isFinite(odds) && odds >= 1.10 && odds <= 2.20;}
    static boolean matchesC(int games, boolean firstBreaker, int won, int total, double odds) {
        return games >= 4 && firstBreaker && total > 0 && won >= 0 && won <= total
                && won * 100L >= total * 68L && prematch(odds);
    }

    static boolean matches(int games, int rank, int otherRank, int won, int total,
                           int otherWon, int otherTotal) {
        return matchesA(games, rank, otherRank, won, total, otherWon, otherTotal, 900, 70);
    }

    static boolean matchesA(int games, int rank, int otherRank, int won, int total,
                            int otherWon, int otherTotal, int gap, int percent) {
        return games >= 5 && rank > 0 && otherRank > 0
                && Math.abs(rank - otherRank) <= gap
                && total > 0 && won >= 0 && won <= total
                && otherTotal > 0 && otherWon >= 0 && otherWon <= otherTotal
                && won * 100L >= total * percent && otherWon * 2L <= otherTotal;
    }
    static boolean matchesB(int games, int won, int total, int saved, int faced, double odds) {
        return matchesB(games, won, total, saved, faced, odds, 55, 70);
    }

    static boolean matchesB(int games, int won, int total, int saved, int faced,
                            double odds, int servePercent, int savedPercent) {
        return games >= 5 && prematch(odds)
                && total > 0 && won >= 0 && won <= total && won * 100L >= total * (long) servePercent
                && faced > 0 && saved >= 3 && saved <= faced && saved * 100L >= faced * (long) savedPercent;
    }
}
