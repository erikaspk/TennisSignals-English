package lt.tenisosignalai;
import java.util.concurrent.TimeUnit;
/** Stagger request starts; network responses still run in parallel. */
final class RateGate {
    private long next;
    void acquire() throws InterruptedException {
        long slot;
        synchronized(this){long now=System.nanoTime();slot=next==0?now:Math.max(now,next);next=slot+TimeUnit.MILLISECONDS.toNanos(110);}
        long wait=slot-System.nanoTime();if(wait>0)TimeUnit.NANOSECONDS.sleep(wait);
    }
}
