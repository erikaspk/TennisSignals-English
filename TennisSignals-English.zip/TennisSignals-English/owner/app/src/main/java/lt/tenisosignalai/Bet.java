package lt.tenisosignalai;

import org.json.*;
import java.util.*;
import java.text.*;

final class Bet {
    // Only explicit whole-match games markets are supported. Unknown market labels are rejected.
    static JSONObject select(JSONArray markets, String side) throws JSONException {
        return select(markets, side, System.currentTimeMillis());
    }

    static JSONObject select(JSONArray markets, String side, long now) throws JSONException {
        return choose(primaryOffers(markets,side,now),1.50,now);
    }
    static boolean ml(JSONObject q) { return "ml".equals(q.optString("unit")); }
    static boolean mlMarket(String name, JSONObject q) {
        String n=Odds.marketName(name);
        String scope=q.optString("scope").toLowerCase(Locale.ROOT), period=q.optString("period").toLowerCase(Locale.ROOT);
        return !scope.contains("set") && !period.contains("set")
                && Arrays.asList("home/away","full time result","match winner","moneyline","money line").contains(n);
    }
    static boolean price(double p) {return Double.isFinite(p) && p>=1.35 && p<=2.20;}
    static JSONArray primaryOffers(JSONArray markets,String side,long now) throws JSONException {
        JSONArray offers=new JSONArray();
        if(markets==null || !(side.equals("1")||side.equals("2")))return offers;
        for(int i=0;i<markets.length();i++) {
            JSONObject q=markets.optJSONObject(i);if(q==null||!"No".equalsIgnoreCase(q.optString("suspended")))continue;
            boolean money=mlMarket(q.optString("odd_name"),q);
            if(!money&&!Odds.gamesMarket(q.optString("odd_name"),q))continue;
            String type=q.optString("type").trim();
            if(!(side.equals(type)||(side.equals("1")&&type.equalsIgnoreCase("Home"))||(side.equals("2")&&type.equalsIgnoreCase("Away"))))continue;
            double p=q.optDouble("value",Double.NaN),line=Odds.number(q,"handicap");
            if(!price(p)||(!money&&!Odds.halfLine(line)))continue;
            if(money&&!q.isNull("handicap")&&!q.optString("handicap").isEmpty())continue;
            SimpleDateFormat date=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.ROOT);
            date.setTimeZone(TimeZone.getTimeZone("UTC"));date.setLenient(false);
            String updated=q.optString("upd");ParsePosition pos=new ParsePosition(0);Date t=date.parse(updated,pos);
            if(t==null||pos.getIndex()!=updated.length()||!Odds.fresh(t.getTime(),now))continue;
            JSONObject c=new JSONObject().put("odds",p).put("side",side).put("market",q.optString("odd_name"))
                .put("quoted",t.getTime()).put("captured",now).put("stake",10).put("kind","inplay")
                .put("source","API Tennis").put("bookmaker",q.optString("bookmaker","Tiekėjas nenurodo"))
                .put("unit",money?"ml":"games").put("scope","match").put("unitVerified",true);
            if(!money)c.put("line",line);offers.put(c);
        }
        return offers;
    }
    static boolean ready(JSONObject bet,long now) {
        return bet!=null && (ml(bet)||("games".equals(bet.optString("unit"))&&Odds.halfLine(bet.optDouble("line",Double.NaN))))
            && "match".equals(bet.optString("scope")) && bet.optBoolean("unitVerified")
            && "inplay".equals(bet.optString("kind")) && ("1".equals(bet.optString("side"))||"2".equals(bet.optString("side")))
            && Odds.fresh(bet.optLong("quoted"),now) && price(bet.optDouble("odds",0));
    }
    static boolean allowed(JSONObject bet,double pre,long now) {
        return ready(bet,now) && (ml(bet)||(Rule.prematch(pre) && (bet.optDouble("line")>=-3.5||pre<=1.20)));
    }
    static boolean preferable(JSONObject a,JSONObject b) {
        if(b==null)return true;
        double da=Math.abs(a.optDouble("odds")-1.50),db=Math.abs(b.optDouble("odds")-1.50);
        if(Math.abs(da-db)>0.000001)return da<db;
        if(ml(a)!=ml(b))return ml(a);
        if(!ml(a)&&a.optDouble("line")!=b.optDouble("line"))return a.optDouble("line")>b.optDouble("line");
        return Odds.newer(a,b);
    }
    static JSONObject choose(JSONArray offers,double pre,long now) {
        return choose(offers, pre, now, false);
    }

    static JSONObject choose(JSONArray offers,double pre,long now,boolean green) {
        JSONObject best=null;if(offers==null)return null;
        // Keep only the newest snapshot of each bookmaker/market/side/line before ranking prices.
        Map<String,JSONObject> latest=new TreeMap<>();
        for(int i=0;i<offers.length();i++) {
            JSONObject q=offers.optJSONObject(i);if(q==null)continue;
            String key=q.optString("source")+":"+q.optString("bookmaker")+":"+q.optString("market")+":"+q.optString("side")+":"+q.optString("line");
            JSONObject old=latest.get(key);if(old==null||q.optLong("quoted")>old.optLong("quoted"))latest.put(key,q);
        }
        for(JSONObject q:latest.values())if (allowed(q,pre,now) && (!green || ml(q) || q.optDouble("line") >= -3.5)
                && preferable(q,best)) best=q;
        return best;
    }
    static String label(JSONObject bet) {
        return ml(bet)?"ML · mačo pergalė":String.format(Locale.ROOT,"AH %+.1f",bet.optDouble("line"));
    }

    static String ahOutcome(JSONObject row) {
        if (row.optJSONObject("bet") == null) return "Be pasiūlymo";
        String status = row.optString("betStatus");
        double profit = row.optDouble("profit", Double.NaN);
        if (Double.isFinite(profit)) {
            if ("Laimėta".equals(status) && profit > 0) return "Laimėta";
            if ("Pralaimėta".equals(status) && profit < 0) return "Pralaimėta";
            if ("Grąžinta".equals(status) && profit == 0) return "Grąžinta";
        }
        return "Laukia rezultato";
    }

    static String summary(JSONObject row) {
        JSONObject bet = row.optJSONObject("bet");
        if (bet == null) return "AH rekomendacija neprieinama";
        return (ml(bet)?"ML · mačo pergalė":String.format(Locale.forLanguageTag("lt"),"Viso mačo geimų AH %+.1f",bet.optDouble("line")))
                + String.format(Locale.forLanguageTag("lt")," @ %.2f · 10 €",bet.optDouble("odds"))
                + " · " + bet.optString("bookmaker", "Bukmekeris nenurodytas")
                + " · " + bet.optString("source", "API Tennis")
                + (bet.has("quoted") ? " · atnaujinta " + new SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(new Date(bet.optLong("quoted"))) : "");
    }

    static void settle(JSONObject row, JSONObject match) throws JSONException {
        JSONObject bet = row.optJSONObject("bet");
        if (bet == null) return;
        if ("Nutraukta".equals(row.optString("outcome"))) {
            row.put("betStatus", "Grąžinta").put("profit", 0);
            return;
        }
        if (ml(bet)) {
            String winner=match.optString("event_winner");
            if(!winner.equals("First Player")&&!winner.equals("Second Player"))return;
            boolean won=winner.equals("First Player")=="1".equals(bet.optString("side"));
            row.put("betStatus",won?"Laimėta":"Pralaimėta")
                .put("profit",won?Math.round(10*(bet.optDouble("odds")-1)*100)/100.0:-10);
            return;
        }
        JSONArray scores = match.optJSONArray("scores");
        if (scores == null || scores.length() < 2) {
            row.put("betStatus", "Trūksta galutinių geimų");
            return;
        }
        int first = 0, second = 0, firstSets = 0, secondSets = 0;
        for (int i = 0; i < scores.length(); i++) {
            JSONObject set = scores.optJSONObject(i);
            int a = set == null ? -1 : set.optInt("score_first", -1);
            int b = set == null ? -1 : set.optInt("score_second", -1);
            int high = Math.max(a, b), low = Math.min(a, b);
            if (!((high == 6 && low >= 0 && low <= 4) || (high == 7 && (low == 5 || low == 6)))) {
                row.put("betStatus", "Nestandartinis arba nepilnas rezultatas");
                return;
            }
            first += a;
            second += b;
            if (a > b) firstSets++; else secondSets++;
        }
        String winner = match.optString("event_winner");
        if (!((firstSets > secondSets && winner.equals("First Player"))
                || (secondSets > firstSets && winner.equals("Second Player")))) {
            row.put("betStatus", "Galutiniai duomenys nesutampa");
            return;
        }
        double difference = ("1".equals(bet.optString("side")) ? first - second : second - first)
                + bet.optDouble("line");
        double profit = difference > 0 ? 10 * (bet.optDouble("odds") - 1) : -10;
        row.put("betStatus", difference > 0 ? "Laimėta" : "Pralaimėta")
                .put("profit", Math.round(profit * 100) / 100.0).put("finalGames", first + ":" + second);
    }
}
