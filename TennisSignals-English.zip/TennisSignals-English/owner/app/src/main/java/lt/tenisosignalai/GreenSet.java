package lt.tenisosignalai;

import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

final class GreenSet {
    private final int[] won = new int[2];
    private final int[] total = new int[2];

    static GreenSet read(JSONObject match, JSONArray scores) {
        JSONArray games = match.optJSONArray("pointbypoint");
        JSONObject current = scores.optJSONObject(scores.length() - 1);
        if (games == null || current == null) return null;
        int set = current.optInt("score_set", scores.length());
        String period = "Set " + set;
        String status = match.optString("event_status").trim();
        if (!status.isEmpty() && !period.equalsIgnoreCase(status)) return null;
        int first = current.optInt("score_first", -1), second = current.optInt("score_second", -1);
        if (first < 0 || second < 0 || first > 6 || second > 6
                || (Math.max(first, second) == 6 && Math.abs(first - second) >= 2)) return null;
        int[] previous = {0, 0};
        GreenSet form = new GreenSet();
        for (int i = 0; i < games.length() && previous[0] + previous[1] < first + second; i++) {
            JSONObject game = games.optJSONObject(i);
            if (game == null || !period.equalsIgnoreCase(game.optString("set_number"))) continue;
            if (game.optInt("number_game") != previous[0] + previous[1] + 1) return null;
            String[] score = game.optString("score").split("\\s*-\\s*");
            if (score.length != 2 || !score[0].matches("[0-6]") || !score[1].matches("[0-6]")) return null;
            int nextFirst = Integer.parseInt(score[0]), nextSecond = Integer.parseInt(score[1]);
            int winner;
            if (nextFirst == previous[0] + 1 && nextSecond == previous[1]) winner = 0;
            else if (nextFirst == previous[0] && nextSecond == previous[1] + 1) winner = 1;
            else return null;
            String serverName = game.optString("player_served");
            int server = "First Player".equals(serverName) ? 0 : "Second Player".equals(serverName) ? 1 : -1;
            int[] points = points(game.optJSONArray("points"), winner);
            if (server < 0 || points == null) return null;
            form.won[server] += points[server];
            form.total[server] += points[0] + points[1];
            previous[0] = nextFirst;
            previous[1] = nextSecond;
        }
        return previous[0] == first && previous[1] == second && form.total[0] > 0 && form.total[1] > 0
                ? form : null;
    }

    private static int[] points(JSONArray rows, int winner) {
        if (rows == null || rows.length() < 3) return null;
        int[] points = {0, 0};
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null || row.optInt("number_point") != i + 1) return null;
            String score = row.optString("score").trim().replaceAll("\\s+", "").toUpperCase(Locale.ROOT);
            int next = -1;
            for (int side = 0; side < 2; side++) {
                points[side]++;
                boolean finished = gameWon(points, side);
                String expected = tennisScore(points[0], points[1]) + "-" + tennisScore(points[1], points[0]);
                if (finished ? side == winner && i == rows.length() - 1 && finalPoint(score, side)
                        : expected.equals(score)) next = side;
                points[side]--;
            }
            if (next < 0) return null;
            points[next]++;
            if (gameWon(points, next)) return points;
        }
        // Some feeds end the point list at game point and record the winner in the game score.
        points[winner]++;
        return gameWon(points, winner) ? points : null;
    }

    private static boolean finalPoint(String score, int side) {
        return score.equals("0-0") || score.equals("GAME") || score.equals("G")
                || score.matches(side == 0 ? "(?:GAME|G)-(?:0|15|30|40)" : "(?:0|15|30|40)-(?:GAME|G)");
    }

    private static boolean gameWon(int[] points, int side) {
        return points[side] >= 4 && points[side] - points[1 - side] >= 2;
    }

    private static String tennisScore(int a, int b) {
        if (a >= 3) return b >= 3 && a > b ? "A" : "40";
        return a == 2 ? "30" : a == 1 ? "15" : "0";
    }

    boolean leads(int side) {
        int other = 1 - side;
        // Return rate is the complement of the opponent's service rate.
        return won[side] * (long) total[other] > won[other] * (long) total[side];
    }

    int[] serve(int side) { return new int[]{won[side], total[side]}; }

    int[] receive(int side) {
        int other = 1 - side;
        return new int[]{total[other] - won[other], total[other]};
    }
}
