package lt.tenisosignalai;

import android.content.SharedPreferences;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.Locale;
import java.util.regex.*;
import org.json.*;

/** Optional, low-volume statistics fallback. Uses a separate product and budget. */
final class FlashStats {
    private static final String HOST = "flashlive-sports.p.rapidapi.com";
    private static final int MONTHLY_LIMIT = 500;
    private static final Pattern FRACTION = Pattern.compile("(?<![0-9])([0-9]{1,4})\\s*/\\s*([0-9]{1,4})(?![0-9])");
    private static final Pattern COUNTRY_SUFFIX = Pattern.compile("\\s+\\([A-Za-z]{3}\\)$");
    private static final Pattern SURNAME_FIRST = Pattern.compile("^(.+?)\\s+((?:\\p{L}\\.\\s*)+)$");
    private JSONArray events;
    private long listTime, retryAfter;
    private String listKey = "", failedKey = "";

    synchronized JSONArray live(String key, SharedPreferences settings) throws IOException, JSONException {
        if (events != null && key.equals(listKey) && System.currentTimeMillis()-listTime<90000) return events;
        JSONArray groups = request("/v1/events/live-list?locale=en_GB&sport_id=2&timezone=0",key,settings)
                .optJSONArray("DATA");
        if (groups == null) throw new IOException("FlashLive · neatpažintas mačų sąrašas");
        JSONArray found = new JSONArray();
        for (int i=0; i<groups.length(); i++) {
            JSONObject group=groups.optJSONObject(i);
            if(group==null)continue;
            JSONArray rows=group.optJSONArray("EVENTS");
            if(rows==null)continue;
            for (int j=0; j<rows.length(); j++) {
                JSONObject event=rows.optJSONObject(j);
                if (event==null || !"LIVE".equalsIgnoreCase(event.optString("STAGE_TYPE"))) continue;
                long start=event.optLong("START_TIME",0);
                if(start<=0)continue;
                found.put(new JSONObject().put("id",event.optString("EVENT_ID"))
                        .put("participant1",event.optString("HOME_PARTICIPANT_NAME_ONE",event.optString("HOME_NAME")))
                        .put("participant2",event.optString("AWAY_PARTICIPANT_NAME_ONE",event.optString("AWAY_NAME")))
                        .put("dateOnly",Instant.ofEpochSecond(start).atZone(ZoneOffset.UTC).toLocalDate().toString()));
            }
        }
        events=found;
        listKey=key;
        listTime=System.currentTimeMillis();
        return events;
    }

    JSONObject statistics(String id, String key, SharedPreferences settings) throws IOException, JSONException {
        return request("/v1/events/statistics?locale=en_GB&event_id="+id,key,settings);
    }

    private JSONObject request(String path,String key,SharedPreferences settings) throws IOException, JSONException {
        MonitoringWindow.requireBackupAllowed();
        synchronized(this) {
            if(System.currentTimeMillis()<RapidQuota.blockedUntil(settings,"flash",key))
                throw new IOException("FlashLive · RapidAPI plano kvota išnaudota");
            if(key.equals(failedKey) && System.currentTimeMillis()<retryAfter)
                throw new IOException("FlashLive · laukiama po API klaidos");
            String month=YearMonth.now(ZoneId.of("Europe/Vilnius")).toString();
            int used=month.equals(settings.getString("flashBudgetMonth",""))?settings.getInt("flashBudgetUsed",0):0;
            if(used>=MONTHLY_LIMIT)throw new IOException("FlashLive · pasiektas vietinis 500 užklausų mėnesio limitas");
            if(!settings.edit().putString("flashBudgetMonth",month).putInt("flashBudgetUsed",used+1).commit())
                throw new IOException("FlashLive · nepavyko įrašyti skaitiklio");
        }
        HttpURLConnection connection=(HttpURLConnection)new URL("https://"+HOST+path).openConnection();
        connection.setConnectTimeout(3000);
        connection.setReadTimeout(3000);
        connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("X-RapidAPI-Host",HOST);
        connection.setRequestProperty("X-RapidAPI-Key",key);
        try {
            int code=connection.getResponseCode();
            synchronized(this) {
                RapidQuota.observe(connection,settings,"flash",key,System.currentTimeMillis());
            }
            if(code==401 || code==403 || code==429) synchronized(this) {
                failedKey=key;
                retryAfter=System.currentTimeMillis()+900000;
            }
            if(code!=200)throw new IOException("FlashLive · HTTP "+code);
            try(BufferedReader reader=new BufferedReader(new InputStreamReader(connection.getInputStream(),StandardCharsets.UTF_8))) {
                StringBuilder body=new StringBuilder();
                char[] buffer=new char[8192];
                int count;
                while((count=reader.read(buffer))!=-1) {
                    MonitoringWindow.requireAllowed();
                    body.append(buffer,0,count);
                }
                return new JSONObject(body.toString());
            }
        } finally {connection.disconnect();}
    }

    static boolean namesMatch(String primary,String external) {
        String name=COUNTRY_SUFFIX.matcher(external.trim()).replaceFirst("");
        if(BackupStats.same(primary,name))return true;
        Matcher reversed=SURNAME_FIRST.matcher(name);
        return reversed.matches() && BackupStats.same(primary,reversed.group(2)+" "+reversed.group(1));
    }

    static JSONObject find(JSONObject match,JSONArray live) {
        JSONObject found=null;
        for(int i=0;i<live.length();i++) {
            JSONObject event=live.optJSONObject(i);
            if(event==null || !match.optString("event_date").equals(event.optString("dateOnly")))continue;
            if(orientation(match,event)==0)continue;
            if(found!=null)return null;
            found=event;
        }
        return found;
    }

    private static int orientation(JSONObject match,JSONObject event) {
        String first=match.optString("event_first_player"), second=match.optString("event_second_player");
        String home=event.optString("participant1"),away=event.optString("participant2");
        boolean direct=namesMatch(first,home)&&namesMatch(second,away);
        boolean reverse=namesMatch(first,away)&&namesMatch(second,home);
        return direct==reverse?0:direct?1:-1;
    }

    static JSONArray convert(JSONObject match,JSONObject event,JSONObject payload) throws JSONException {
        if(!match.optString("event_date").equals(event.optString("dateOnly")))return null;
        int order=orientation(match,event);
        if(order==0)return null;
        JSONArray stages=payload.optJSONArray("DATA");
        JSONArray scores=match.optJSONArray("scores");
        if(stages==null || scores==null || scores.length()==0)return null;
        int[] games={0,0};
        for(int i=0;i<scores.length();i++) {
            JSONObject set=scores.optJSONObject(i);
            if(set==null || set.optInt("score_first",-1)<0 || set.optInt("score_second",-1)<0)return null;
            games[0]+=set.optInt("score_first");
            games[1]+=set.optInt("score_second");
        }
        JSONArray result=new JSONArray();
        boolean verifiedGames=false;
        for(int i=0;i<stages.length();i++) {
            JSONObject stage=stages.optJSONObject(i);
            if(stage==null || !"Match".equalsIgnoreCase(stage.optString("STAGE_NAME")))continue;
            JSONArray groups=stage.optJSONArray("GROUPS");
            if(groups==null)continue;
            for(int j=0;j<groups.length();j++) {
                JSONObject group=groups.optJSONObject(j);
                JSONArray items=group==null?null:group.optJSONArray("ITEMS");
                if(items==null)continue;
                for(int k=0;k<items.length();k++) {
                    JSONObject item=items.optJSONObject(k);
                    if(item==null)continue;
                    String name=item.optString("INCIDENT_NAME").trim().toLowerCase(Locale.ROOT);
                    String first=item.optString(order>0?"VALUE_HOME":"VALUE_AWAY");
                    String second=item.optString(order>0?"VALUE_AWAY":"VALUE_HOME");
                    if(name.equals("total games won") || name.equals("games won")) {
                        verifiedGames=gamesMatch(first,games[0],games[0]+games[1])
                                && gamesMatch(second,games[1],games[0]+games[1]);
                    } else if(name.equals("win on 1st serve") || name.equals("1st serve points won")
                            || name.equals("first serve points won") || name.equals("break points saved")) {
                        String label=name.equals("break points saved")?name:"1st serve points won";
                        add(result,match.optString("first_player_key"),label,first);
                        add(result,match.optString("second_player_key"),label,second);
                    }
                }
            }
        }
        return verifiedGames && result.length()>0?result:null;
    }

    private static boolean gamesMatch(String value,int won,int total) {
        if(value.trim().equals(Integer.toString(won)))return true;
        Matcher ratio=FRACTION.matcher(value);
        return ratio.find() && Integer.parseInt(ratio.group(1))==won
                && Integer.parseInt(ratio.group(2))==total;
    }

    private static void add(JSONArray rows,String player,String name,String value) throws JSONException {
        Matcher ratio=FRACTION.matcher(value);
        if(player.isEmpty() || !ratio.find())return;
        int won=Integer.parseInt(ratio.group(1)), total=Integer.parseInt(ratio.group(2));
        if(won>total || (total==0 && name.equals("1st serve points won")))return;
        rows.put(new JSONObject().put("player_key",player).put("stat_period","match")
                .put("stat_name",name).put("stat_won",won).put("stat_total",total));
    }
}
