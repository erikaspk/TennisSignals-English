package lt.tenisosignalai;

import java.net.HttpURLConnection;
import android.content.SharedPreferences;

final class RapidQuota {
    private static final long MAX_RESET_SECONDS = 32L * 24 * 3600;

    static long blockedUntil(SharedPreferences settings,String prefix,String key) {
        if(settings==null || settings.getInt(prefix+"QuotaKey",0)!=key.hashCode())return 0;
        return settings.getLong(prefix+"QuotaUntil",0);
    }

    static void observe(HttpURLConnection connection,SharedPreferences settings,String prefix,String key,long now) {
        if(settings==null)return;
        long seconds=0;
        for(String header:new String[]{"x-ratelimit-requests","x-rate-limit-rapid-free-plans-hard-limit"}) {
            if(!"0".equals(connection.getHeaderField(header+"-remaining")))continue;
            long reset=seconds(connection.getHeaderField(header+"-reset"));
            seconds=Math.max(seconds,reset==0?900:reset);
        }
        if(seconds>0)settings.edit().putInt(prefix+"QuotaKey",key.hashCode())
                .putLong(prefix+"QuotaUntil",now+seconds*1000).apply();
    }

    private static long seconds(String header) {
        try {
            long value=Long.parseLong(header);
            return value>0 && value<=MAX_RESET_SECONDS?value:0;
        }catch(NumberFormatException ignored){return 0;}
    }
}
