package lt.tenisosignalai;

import org.json.*;
import java.util.*;

/** Normalizes provider quotes without replacing historical signal-time prices. */
final class Odds {
    static final List<String> BOOK_ORDER = Arrays.asList("bet365", "pinnacle", "betsson", "bwin", "betfair", "draftkings", "melbet", "fonbet", "marathonbet");
    static int bookRank(String book) { int i = BOOK_ORDER.indexOf(book.toLowerCase(Locale.ROOT)); return i < 0 ? 100 : i; }
    static List<String> keys(JSONObject object) {
        List<String> keys = new ArrayList<>();
        if (object != null) object.keys().forEachRemaining(keys::add);
        Collections.sort(keys); return keys;
    }
    static double number(JSONObject object, String key) {
        Object raw=object.opt(key);
        if(raw==null||raw==JSONObject.NULL)return Double.NaN;
        try {return Double.parseDouble(raw.toString().trim());}catch(NumberFormatException invalid){return Double.NaN;}
    }
    static boolean price(double value) { return Double.isFinite(value) && value > 1 && value < 10000; }
    static boolean halfLine(double line) {
        return Double.isFinite(line) && Math.abs(line) <= 50 && Math.abs(line * 2 - Math.rint(line * 2)) < 0.00001
                && Math.abs(line - Math.rint(line)) > 0.00001;
    }
    static boolean fresh(long timestamp, long now) { return timestamp > 0 && now - timestamp >= -30000 && now - timestamp <= 30000; }
    static String marketName(String name) { return name.split("\\|", 2)[0].trim().toLowerCase(Locale.ROOT); }
    static boolean gamesMarket(String name, JSONObject quote) {
        String market = marketName(name);
        String unit=quote.optString("handicapUnit",quote.optString("unit"));
        if(!unit.isEmpty()&&!unit.equalsIgnoreCase("games"))return false;
        if (quote.optString("scope").toLowerCase(Locale.ROOT).contains("set")
                || quote.optString("period").toLowerCase(Locale.ROOT).contains("set")) return false;
        if (market.contains("set") || market.contains("half") || market.matches(".*\\b[1-5](st|nd|rd|th)?\\b.*")) return false;
        boolean explicit = Arrays.asList("match games handicap", "asian handicap (games)", "asian handicap games",
                "match handicap (games)", "games handicap", "handicap games", "game handicap", "match game handicap").contains(market);
        boolean units = "games".equalsIgnoreCase(quote.optString("handicapUnit", quote.optString("unit")));
        return explicit || (market.equals("asian handicap") && units);
    }
    static boolean secondaryGamesMarket(String market, JSONObject quote, String book) {
        if(gamesMarket(market,quote))return true;
        // Provider market 13_2 / Asian Handicap is the main match market, not Set Winner.
        // These bookmakers explicitly define their standard tennis match handicap by games.
        // Other generic bookmakers remain unverified rather than inferring units from line size.
        String unit=quote.optString("handicapUnit",quote.optString("unit"));
        if(!unit.isEmpty()&&!unit.equalsIgnoreCase("games"))return false;
        return marketName(market).equals("asian handicap")
                && !quote.optString("scope").toLowerCase(Locale.ROOT).contains("set")
                && !quote.optString("period").toLowerCase(Locale.ROOT).contains("set")
                && (book.equalsIgnoreCase("FonBet") || book.equalsIgnoreCase("Bet365"));
    }
    static JSONObject prematchPrimary(JSONObject market, long now) throws JSONException {
        if (market == null) return null;
        JSONObject home = market.optJSONObject("Home"), away = market.optJSONObject("Away");
        if (home == null || away == null) return null;
        List<String> books = keys(home);
        books.sort(Comparator.comparingInt(Odds::bookRank).thenComparing(String::compareToIgnoreCase));
        for (String book : books) {
            double first = home.optDouble(book, Double.NaN), second = away.optDouble(book, Double.NaN);
            if (!price(first) || !price(second)) continue;
            return new JSONObject().put("source", "API Tennis").put("bookmaker", book).put("first", first).put("second", second)
                    .put("captured", now).put("market", "Home/Away").put("kind", "pre")
                    .put("timestampKnown", false);
        }
        return null;
    }
    static JSONObject prematchSecondary(JSONObject response, long start, boolean reverse, long now) throws JSONException {
        JSONObject result = response.optJSONObject("result");
        JSONArray prices = result == null ? null : result.optJSONArray("Full Time Result");
        if (prices == null || start <= 0) return null;
        // Choose each bookmaker's latest genuine pre-match quote before comparing books.
        Map<String, JSONObject> latest = new TreeMap<>();
        for (int i=0; i<prices.length(); i++) {
            JSONObject q=prices.optJSONObject(i); if(q==null || !"pre".equalsIgnoreCase(q.optString("oddType")) || !q.optString("line").isEmpty()) continue;
            long t=q.optLong("addTime",0)*1000L;
            String book=q.optString("bookmaker");
            if(book.isEmpty() || t<=0 || t>start || t>now+30000) continue;
            JSONObject old=latest.get(book);
            if(old==null || t>old.optLong("addTime")*1000L) latest.put(book,q);
        }
        List<String> books=new ArrayList<>(latest.keySet());
        books.sort(Comparator.comparingInt(Odds::bookRank).thenComparing(String::compareToIgnoreCase));
        for(String book:books) {
            JSONObject q=latest.get(book);
            double one=q.optDouble("od1",Double.NaN), two=q.optDouble("od2",Double.NaN);
            if(!price(one)||!price(two)) continue;
            return new JSONObject().put("source","Matchstat / RapidAPI").put("bookmaker",book)
                    .put("first",reverse?two:one).put("second",reverse?one:two).put("quoted",q.optLong("addTime")*1000L)
                    .put("captured",now).put("timestampKnown",true).put("market","Full Time Result").put("kind","pre");
        }
        return null;
    }
    static JSONObject liveSecondary(JSONObject response, String primarySide, boolean reverse, long now) throws JSONException {
        JSONObject markets=response.optJSONObject("result");
        if(markets==null) return new JSONObject().put("reason","Matchstat: nėra gyvų rinkų");
        JSONObject best=null, unverified=null;
        JSONArray offers=new JSONArray();
        int stale=0, outside=0, ambiguous=0;
        String secondarySide=reverse?(primarySide.equals("1")?"2":"1"):primarySide;
        for(String market:keys(markets)) {
            String base=marketName(market);
            boolean money=base.equals("full time result");
            if(!money&&!base.contains("handicap")) continue;
            JSONObject books=markets.optJSONObject(market); if(books==null) continue;
            for(String book:keys(books)) {
                JSONObject q=books.optJSONObject(book); if(q==null||!"inplay".equalsIgnoreCase(q.optString("oddType"))) continue;
                // A missing suspension flag is represented as unknown; the quote is a provider snapshot, not a guarantee of acceptance.
                if(q.optBoolean("suspended",false)||"Yes".equalsIgnoreCase(q.optString("suspended"))) continue;
                long t=q.optLong("addTime",0)*1000L;
                if(!fresh(t,now)){stale++;continue;}
                double odds=q.optDouble(secondarySide.equals("1")?"od1":"od2",Double.NaN);
                double line=number(q,"line");
                if(secondarySide.equals("2")) line=-line;
                if(!Bet.price(odds)||(!money&&!halfLine(line))||(money&&!q.isNull("line")&&!q.optString("line").isEmpty())){outside++;continue;}
                JSONObject candidate=new JSONObject().put("odds",odds).put("side",primarySide)
                        .put("market",market).put("bookmaker",book).put("source","Matchstat / RapidAPI")
                        .put("quoted",t).put("captured",now).put("stake",10).put("kind","inplay")
                        .put("suspensionKnown",q.has("suspended"));
                if(!money)candidate.put("line",line);
                if(!money&&!secondaryGamesMarket(market,q,book)) {
                    if(base.equals("asian handicap")) {
                        ambiguous++; candidate.put("unitVerified",false);
                        if(newer(candidate,unverified)) unverified=candidate;
                    }
                    continue;
                }
                candidate.put("unit",money?"ml":"games").put("scope","match").put("unitVerified",true)
                        .put("unitEvidence",gamesMarket(market,q)?"explicit_market_or_units":"provider_main_market_and_bookmaker_tennis_rules");
                offers.put(candidate);
            }
        }
        best=Bet.choose(offers,1.50,now);
        JSONObject out=new JSONObject().put("offers",offers).put("reason",best!=null?"Matchstat: gautas AH / ML"
                : ambiguous>0?"Matchstat AH gauta, bet API nepatvirtina geimų vienetų"
                : "Matchstat: nėra šviežios AH / ML 1,35–2,20 (pasenę "+stale+", netinkamos linijos/kainos "+outside+")");
        if(best!=null) out.put("bet",best);
        if(unverified!=null) out.put("unverifiedAH",unverified);
        return out;
    }
    static boolean newer(JSONObject a, JSONObject b) {
        if(b==null) return true;
        long at=a.optLong("quoted"), bt=b.optLong("quoted");
        if(at!=bt) return at>bt;
        int comparison=Integer.compare(bookRank(a.optString("bookmaker")),bookRank(b.optString("bookmaker")));
        if(comparison!=0)return comparison<0;
        comparison=a.optString("bookmaker").compareToIgnoreCase(b.optString("bookmaker"));
        if(comparison!=0)return comparison<0;
        return a.optDouble("line")<b.optDouble("line");
    }
    static String prematchSummary(JSONObject row) {
        JSONObject q=row.optJSONObject("prematch");
        if(q==null) return "Prematch · koeficientas neišsaugotas";
        return String.format(Locale.forLanguageTag("lt"),"Prematch @ %.2f · %s · %s",q.optDouble("odds"),q.optString("bookmaker"),q.optString("source"));
    }
}
