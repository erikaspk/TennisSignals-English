package lt.tenisosignalai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.widget.*;
import android.graphics.Color;
import java.util.*;
import org.json.*;

public final class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        settings = getSharedPreferences("monitor", MODE_PRIVATE);
        if(state!=null){page=state.getInt("page",0);historyDate=state.getString("historyDate","");historyTier=state.getString("historyTier","");showOlder=state.getBoolean("showOlder",false);}
        if ("legacy".equals(historyTier)) historyTier = "";
        render();
    }

    private String historyDate="",historyTier="";
    private boolean showOlder;
    private final Set<String> expandedHistory=new HashSet<>();
    private ScrollView scrollView;
    private int renderedPage=-1;
    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);state.putInt("page",page);state.putString("historyDate",historyDate);
        state.putString("historyTier",historyTier);state.putBoolean("showOlder",showOlder);
    }
    private SharedPreferences settings;
    private LinearLayout panel;
    private int page;
    private final SharedPreferences.OnSharedPreferenceChangeListener changes = (prefs, field) -> {
        if (field == null || (page == 0 && field.equals("live"))
                || ((page == 1 || page == 2) && field.startsWith("history:"))) render();
    };

    @Override protected void onStart() {
        super.onStart();
        settings.registerOnSharedPreferenceChangeListener(changes);
        render();
    }

    @Override protected void onResume() {
        super.onResume();
        if (settings.getBoolean("monitoringEnabled", false) && !settings.getString("key", "").isEmpty()) {
            startForegroundService(new Intent(this, Monitor.class));
        }
        render();
    }

    @Override protected void onStop() {
        settings.unregisterOnSharedPreferenceChangeListener(changes);
        super.onStop();
    }

    private void render() {
        int previousScroll=scrollView!=null&&renderedPage==page?scrollView.getScrollY():0;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                new int[]{0xff080c24, 0xff121b48, 0xff0a102c}));
        getWindow().setStatusBarColor(0xff080c24);
        getWindow().setNavigationBarColor(0xff080c24);
        root.setFitsSystemWindows(true);
        ScrollView scroll = new ScrollView(this);
        scrollView=scroll;renderedPage=page;
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int padding = (int) (18 * getResources().getDisplayMetrics().density);
        panel.setPadding(padding, padding, padding, padding);
        scroll.addView(panel);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        String[] tabs = {"Gyvai", "Signalai", "Statistika", "Profilis"};
        label("TENISO SIGNALAI   /   LIVE", 14);
        if (settings.getBoolean("creator", false)) {
            label("API Tennis · 24/7 | Matchstat · 10:00–22:00 LT", 13);
            if (!MonitoringWindow.workingTime(System.currentTimeMillis())) {
                label("Pagrindinis API Tennis veikia. Matchstat ilsisi iki 10:00.", 14);
            }
        }
        label(tabs[page].toUpperCase(Locale.forLanguageTag("lt")), 34);
        if (page == 0) live();
        if (page == 1 || page == 2) history();
        if (page == 3) profile();

        LinearLayout menu = new LinearLayout(this);
        menu.setBackgroundColor(0xff141a39);
        for (int i = 0; i < tabs.length; i++) {
            final int tab = i;
            Button button = new Button(this, null, android.R.attr.borderlessButtonStyle);
            button.setText(tabs[i]);
            button.setAllCaps(false);
            button.setTextColor(i == page ? 0xffa58aff : 0xffc7c7c7);
            button.setTextSize(13);
            button.setPadding(0, 0, 0, 0);
            button.setSelected(i == page);
            button.setMinWidth(0);
            button.setMinimumWidth(0);
            menu.addView(button, new LinearLayout.LayoutParams(0, -2, 1));
            button.setOnClickListener(view -> { page = tab; render(); });
        }
        root.addView(menu);
        setContentView(root);
        scroll.post(()->scroll.scrollTo(0,previousScroll));
    }

    private void label(String text, int size) {
        label(text, size, size >= 22 ? 0xffa58aff : 0xffeeeeee);
    }

    private void label(String text, int size, int color) {
        TextView line = new TextView(this);
        line.setText(text);
        line.setTextSize(size);
        line.setTextColor(color);
        if (size >= 18) line.setTypeface(android.graphics.Typeface.create(
                "sans-serif-condensed", android.graphics.Typeface.BOLD));
        line.setPadding(0, 8, 0, 12);
        panel.addView(line);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private android.graphics.drawable.GradientDrawable card(int border) {
        android.graphics.drawable.GradientDrawable shape = new android.graphics.drawable.GradientDrawable();
        shape.setColors(new int[]{0xff20264d, 0xff131a36});
        shape.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TL_BR);
        shape.setCornerRadius(dp(18));
        shape.setStroke(dp(1), border);
        return shape;
    }

    private void live() {
        boolean creator = settings.getBoolean("creator", false);
        if (creator) label(settings.getString("backupStatus", "Atsarginis šaltinis · nustatymai profilyje"), 14);
        try {
            String snapshot = settings.getString("live", "");
            if (snapshot.isEmpty()) {
                label(creator ? "Paleisk stebėjimą skiltyje „Profilis“ ir palauk pirmo atnaujinimo."
                        : "Gyvų mačų sąrašas kol kas tuščias.", 16);
                return;
            }
            JSONArray rows = new JSONArray(snapshot);
            Set<String> active = new HashSet<>();
            int pending = 0;
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.getJSONObject(i);
                String countryStatus = row.optString("countryStatus");
                if (!"blocked".equals(countryStatus)) active.add(row.getString("id"));
                if ("pending".equals(countryStatus)) pending++;
            }
            Set<String> selected = new HashSet<>(settings.getStringSet("selected", Collections.emptySet()));
            selected.retainAll(active);
            label("Vyksta: " + rows.length() + " · stebimi: "
                    + (creator ? String.valueOf(active.size() - pending) : selected.size() + "/3"), 17);
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.getJSONObject(i);
                String id = row.getString("id");
                CheckBox choice = new CheckBox(this);
                String countryStatus = row.optString("countryStatus");
                boolean blocked = "blocked".equals(countryStatus);
                boolean waiting = "pending".equals(countryStatus);
                if (!creator) {
                    choice.setText(row.getString("label") + (blocked ? "\nMačas nestebimas" : ""));
                } else if (blocked || waiting) {
                    choice.setText(row.getString("label") + "\n" + (blocked
                            ? "Nestebimas · abu žaidėjai iš tos pačios šalies"
                            : "Laukiama žaidėjų šalių · Matchstat pristabdytas"));
                } else {
                    choice.setText(row.getString("label") + "\n" + settings.getString("c:" + id, "C · laukiama patikros")
                        + "\n" + settings.getString("source:" + id, "Statistika · laukiama")
                        + (settings.contains("ahPending:" + id) ? "\n" + settings.getString("ahPending:" + id, "") : ""));
                }
                choice.setTextColor(0xffeeeeff);
                choice.setButtonTintList(android.content.res.ColorStateList.valueOf(0xffa58aff));
                choice.setChecked(!blocked && (creator ? !waiting : selected.contains(id)));
                choice.setEnabled(!creator && !blocked);
                choice.setBackground(card(0xff303c68));
                choice.setMinHeight(dp(62));
                LinearLayout.LayoutParams item = new LinearLayout.LayoutParams(-1, -2);
                item.bottomMargin = dp(8);
                panel.addView(choice, item);
                choice.setOnClickListener(view -> {
                    if (choice.isChecked()) {
                        if (selected.size() >= 3) {
                            choice.setChecked(false);
                            Toast.makeText(this, "Galima stebėti iki 3 mačų", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        selected.add(id);
                    } else {
                        selected.remove(id);
                    }
                    settings.edit().putStringSet("selected", new HashSet<>(selected)).apply();
                    render();
                });
            }
        } catch (JSONException invalid) {
            label("Gyvų mačų sąrašo nepavyko nuskaityti.", 16);
        }
    }

    private List<JSONObject> signalHistory() {
        List<JSONObject> rows = new ArrayList<>();
        for (Map.Entry<String, ?> entry : settings.getAll().entrySet()) {
            if (!entry.getKey().startsWith("history:")) continue;
            try { rows.add(new JSONObject((String) entry.getValue())); }
            catch (JSONException invalid) { continue; }
        }
        return SignalPolicy.filter(SignalPolicy.displayHistory(SignalPolicy.history(rows)), "", "");
    }

    private String overallRoi(List<JSONObject> rows) {
        double profit = 0;
        double stakes = 0;
        for (JSONObject row : rows) {
            String outcome = Bet.ahOutcome(row);
            if (!"Laimėta".equals(outcome) && !"Pralaimėta".equals(outcome)) continue;
            double stake = row.optJSONObject("bet").optDouble("stake", 10);
            if (!Double.isFinite(stake) || stake <= 0) continue;
            profit += row.optDouble("profit");
            stakes += stake;
        }
        return stakes == 0 ? "—" : String.format(Locale.forLanguageTag("lt"), "%+.1f %%", 100 * profit / stakes);
    }

    private void history() {
        List<JSONObject> all = signalHistory();
        List<JSONObject> rows = SignalPolicy.filter(all, historyDate, historyTier);
        historyFilters();
        List<android.view.View> olderTableRows=new ArrayList<>();
        int wins = 0, losses = 0, pending = 0, interrupted = 0, withoutAh = 0;
        for (JSONObject row : rows) {
            String outcome = Bet.ahOutcome(row);
            switch (outcome) {
                case "Laimėta": wins++; break;
                case "Pralaimėta": losses++; break;
                case "Grąžinta": interrupted++; break;
                case "Be pasiūlymo": withoutAh++; break;
                default: pending++;
            }
        }
        int full=Math.min(5,rows.size());
        for(int i=0;i<full;i++)panel.addView(historyCard(rows.get(i),false));
        if(rows.size()>5) {
            Button older=new Button(this);older.setAllCaps(false);
            older.setText((showOlder?"▴ Slėpti senesnius":"▾ Senesni signalai")+" ("+(rows.size()-5)+")");
            LinearLayout archive=new LinearLayout(this);archive.setOrientation(LinearLayout.VERTICAL);
            archive.setVisibility(showOlder?android.view.View.VISIBLE:android.view.View.GONE);
            for(int i=5;i<rows.size();i++)archive.addView(historyCard(rows.get(i),true));
            older.setOnClickListener(v->{showOlder=!showOlder;archive.setVisibility(showOlder?android.view.View.VISIBLE:android.view.View.GONE);
                for(android.view.View row:olderTableRows)row.setVisibility(showOlder?android.view.View.VISIBLE:android.view.View.GONE);
                older.setText((showOlder?"▴ Slėpti senesnius":"▾ Senesni signalai")+" ("+archive.getChildCount()+")");});
            panel.addView(older);panel.addView(archive);
        }
        if(rows.isEmpty())label("Pagal pasirinktus filtrus signalų nėra.",16);
        if (page == 1 && rows.isEmpty()) label("Signalų istorija dar tuščia.", 16);
        if (page == 2) {
            label("10 € UŽ PASIŪLYMĄ", 22);
            TableLayout table = new TableLayout(this);
            table.setStretchAllColumns(true);
            String[] headers = {"Signalas / AH / ML", "Koef.", "Pelnas"};
            TableRow header = new TableRow(this);
            for (String text : headers) {
                TextView cell = new TextView(this);
                cell.setText(text); cell.setTextColor(0xffa58aff); cell.setPadding(4, 12, 4, 12);
                header.addView(cell);
            }
            table.addView(header);
            int tableIndex=0;
            double oddsSum = 0;
            int oddsCount = 0;
            for (JSONObject row : rows) {
                JSONObject bet = row.optJSONObject("bet");
                double odds = bet == null ? Double.NaN : bet.optDouble("odds", Double.NaN);
                if (Double.isFinite(odds) && odds > 1) {
                    oddsSum += odds;
                    oddsCount++;
                }
                TableRow tr = new TableRow(this);
                String title = row.optString("title");
                String[] cells = {title + (bet == null ? "" : "\n"+Bet.label(bet)),
                        bet == null ? "—" : String.format(Locale.ROOT, "%.2f\n%s", bet.optDouble("odds"), bet.optString("bookmaker", "")),
                        row.has("profit") ? String.format(Locale.ROOT, "%+.2f €", row.optDouble("profit")) : "—"};
                for (int column = 0; column < cells.length; column++) {
                    TextView cell = new TextView(this);
                    cell.setText(cells[column]); cell.setTextSize(12); cell.setTextColor(0xffeeeeff);
                    cell.setPadding(4, 10, 4, 10);
                    if (column == 0) cell.setMaxWidth(dp(175));
                    tr.addView(cell);
                }
                if(tableIndex++>=5){tr.setVisibility(showOlder?android.view.View.VISIBLE:android.view.View.GONE);olderTableRows.add(tr);}
                table.addView(tr);
            }
            panel.addView(table);
            label("Vidutinis koeficientas · " + (oddsCount == 0 ? "—"
                    : String.format(Locale.forLanguageTag("lt"), "%.2f", oddsSum / oddsCount)), 18);
            label("Žalia · geltona C. Kaupiamasis grynasis rezultatas pagal signalo datą. Seni signalai be koeficientų neįtraukti.", 14);
            List<JSONObject> chronological = new ArrayList<>(rows);
            Collections.reverse(chronological);
            panel.addView(new ProfitChart(this, chronological,historyTier), new LinearLayout.LayoutParams(-1, dp(240)));
            for (String tier : new String[]{"green", "yellow"}) {
                if(!historyTier.isEmpty()&&!historyTier.equals(tier))continue;
                double profit = 0;
                int settled = 0;
                for (JSONObject row : rows) {
                    if (tier.equals(row.optString("tier")) && row.has("profit")) {
                        profit += row.optDouble("profit");
                        settled++;
                    }
                }
                label(String.format(Locale.forLanguageTag("lt"), "%s · %d atsiskaitytų · %+.2f €", 
                        tier.equals("green") ? "Žalias" : tier.equals("yellow") ? "Geltonas" : "Rudas", settled, profit), 16);
                android.view.View filterLabel=panel.getChildAt(panel.getChildCount()-1);
                filterLabel.setContentDescription("Filtruoti pagal "+tier+" signalus");
                filterLabel.setOnClickListener(v->{historyTier=historyTier.equals(tier)?"":tier;showOlder=false;render();});
            }
            label("Bendras ROI · " + overallRoi(all), 22);
            int completed = wins + losses;
            label(completed == 0 ? "AH / ML pataikymas: —" : String.format(Locale.forLanguageTag("lt"),
                    "AH / ML pataikymas: %.1f %% (%d iš %d)", wins * 100.0 / completed, wins, completed), 22);
            label("Laimėta: " + wins + " · Pralaimėta: " + losses
                    + "\nLaukia rezultato: " + pending + " · Grąžinta: " + interrupted + "\nBe pasiūlymo: " + withoutAh, 16);
        }
    }

    private void profile() {
        profileIdentity();
        boolean creator = settings.getBoolean("creator", false);
        label(creator ? "Narystė · Kūrėjas" : "Narystė · Free", 20);
        if (!creator) {
            panel.getChildAt(panel.getChildCount() - 1).setOnLongClickListener(view -> {
                EditText code = new EditText(this);
                code.setSingleLine(true);
                code.setHint("Kūrėjo kodas");
                code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                        .setTitle("Kūrėjo režimas")
                        .setView(code)
                        .setNegativeButton("Atšaukti", null)
                        .setPositiveButton("✓", null)
                        .create();
                dialog.show();
                dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(button -> {
                    if (!validCreatorCode(code.getText().toString().trim())) {
                        code.setError("Neteisingas kūrėjo kodas");
                        return;
                    }
                    settings.edit().putBoolean("creator", true).apply();
                    dialog.dismiss();
                    render();
                });
                return true;
            });
        }
        label("Free · iki 3 gyvų mačų vienu metu.\nVisi palaikomi mačai · 3,99 € / savaitę arba 9,99 € / mėnesį.", 16);
        if (!creator) return;

        label("Pasiūlymas: AH arba ML · 1,35–2,20 · tikslas apie 1,50. Žaliems AH nuo −3,5. Geltonam C AH žemiau −3,5 tik su prematch ≤1,20.", 14);
        label("API Tennis stebimas visą parą. Matchstat veikia 10:00–22:00 Lietuvos laiku.", 14);
        label("Nuo 6-ojo geimo · pirmas padavimas ≥70 % / ≤50 % · reitingų skirtumas ≤900", 15);
        label("Visoms taisyklėms būtinas prematch ML 1,10–2,20.", 15);
        label("B · pirmas padavimas ≥55 % · atremti bent 3 breiko taškai ir ≥70 % · dabartiniame sete geresnis padavimas ir priėmimas už varžovo", 15);
        label("Geltonas C · ≥4 užbaigti geimai · prematch 1,10–2,20 · pirmas breikas mače · pirmas padavimas ≥68 %", 15, 0xffffd44d);
        label("API raktai", 20);
        publisherSettings();
        apiKeyCard("API Tennis", "key");
        apiKeyCard("Matchstat / RapidAPI", "backupKey");
        apiKeyCard("Nemokami šaltiniai / RapidAPI · pasirenkamas", "flashKey");
        label("Matchstat · 4 500 iki 20:00 LT, 5 000 nuo 20:00 LT. Nemokami šaltiniai po Matchstat ribos: FlashLive, Tennis ATP/WTA/ITF, OS Sports Perform, SportScore.", 14);
        java.time.ZonedDateTime now=java.time.ZonedDateTime.now(java.time.ZoneId.of("Europe/Vilnius"));
        if(now.toLocalDate().toString().equals(settings.getString("rapidBudgetDay",""))) {
            label("Šiandien Matchstat · "+settings.getInt("rapidBudgetUsed",0)
                    +" / "+BackupStats.dailyLimit(now.toInstant().toEpochMilli())
                    +" · sąrašai "+settings.getInt("rapidBudgetList",0)
                    +" · statistika "+settings.getInt("rapidBudgetStats",0)
                    +" · prematch "+settings.getInt("rapidBudgetPre",0)
                    +" · gyvi koef. "+settings.getInt("rapidBudgetLive",0),14);
        }
        if(java.time.YearMonth.from(now).toString().equals(settings.getString("flashBudgetMonth",""))) {
            label("FlashLive šį mėnesį · "+settings.getInt("flashBudgetUsed",0)+" / 500",14);
        }
        for(ExtraStats source:ExtraStats.values()) {
            String prefix="extra"+source.name();
            if(java.time.YearMonth.from(now).toString().equals(settings.getString(prefix+"Month",""))) {
                label(source.label+" šį mėnesį · "+settings.getInt(prefix+"Used",0)+" / 500",14);
            }
        }
        label(settings.getString("backupStatus", "Atsarginis šaltinis dar nepatikrintas"), 14);
        Button start = new Button(this);
        start.setText("Pradėti stebėti");
        start.setOnClickListener(view -> {
            if (settings.getString("key", "").isEmpty()) {
                Toast.makeText(this, "Palaikyk API Tennis kortelę ir įvesk raktą", Toast.LENGTH_SHORT).show();
                return;
            }
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                return;
            }
            begin();
        });
        panel.addView(start);
        Button stop = new Button(this);
        stop.setText("Stabdyti");
        stop.setOnClickListener(view -> {
            settings.edit().putBoolean("monitoringEnabled", false).apply();
            stopService(new Intent(this, Monitor.class));
            Toast.makeText(this, "Stebėjimas sustabdytas", Toast.LENGTH_SHORT).show();
        });
        panel.addView(stop);

    }

    private void publisherSettings() {
        label(settings.getString("relayStatus", "Signalų persiuntimas nesukonfigūruotas"), 14);
        Button relay = new Button(this);
        relay.setText("Signalų persiuntimas");
        panel.addView(relay);
        relay.setOnClickListener(view -> {
            LinearLayout fields = new LinearLayout(this);
            fields.setOrientation(LinearLayout.VERTICAL);
            EditText url = new EditText(this);
            url.setSingleLine(true);
            url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
            url.setHint("HTTPS serverio adresas");
            url.setText(settings.getString("relayUrl", ""));
            EditText token = new EditText(this);
            token.setSingleLine(true);
            token.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            token.setHint("Siuntėjo raktas");
            token.setText(settings.getString("relayOwnerKey", ""));
            fields.addView(url);
            fields.addView(token);
            android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                    .setTitle("Signalų persiuntimas").setView(fields)
                    .setNegativeButton("Atšaukti", null).setPositiveButton("Išsaugoti", null).create();
            dialog.setOnShowListener(ignored -> dialog.getButton(-1).setOnClickListener(save -> {
                String address = url.getText().toString().trim();
                String key = token.getText().toString().trim();
                if (!address.isEmpty()) {
                    try { address = RelayHttp.base(address).toString(); }
                    catch (IllegalArgumentException invalid) { url.setError("Įvesk HTTPS adresą"); return; }
                    if (!key.matches("[A-Za-z0-9_-]{32,256}")) { token.setError("Patikrink siuntėjo raktą"); return; }
                }
                settings.edit().putString("relayUrl", address).putString("relayOwnerKey", address.isEmpty() ? "" : key)
                        .remove("relayStatus").apply();
                dialog.dismiss();
                render();
            }));
            dialog.show();
        });
    }

    private void apiKeyCard(String title, String preference) {
        boolean configured = !settings.getString(preference, "").isEmpty();
        TextView tile = new TextView(this);
        tile.setText(title + "   ·   " + (configured ? "● Active" : "○ Inactive"));
        tile.setTextColor(configured ? 0xffa5ff40 : 0xffb0b5c2);
        tile.setTextSize(16);
        tile.setPadding(dp(14), dp(12), dp(14), dp(12));
        tile.setBackground(card(0xff303c68));
        tile.setContentDescription(title + ". Palaikyk, kad pakeistum raktą.");
        tile.setOnLongClickListener(view -> {
            EditText input = new EditText(this);
            input.setSingleLine(true);
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            input.setHint("Įklijuok arba įrašyk raktą");
            input.setText(settings.getString(preference, ""));
            input.selectAll();
            android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                    .setTitle(title)
                    .setView(input)
                    .setNegativeButton("Atšaukti", null)
                    .setPositiveButton("✓", null)
                    .create();
            dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            input.requestFocus();
            dialog.show();
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(button -> {
                settings.edit().putString(preference, input.getText().toString().trim()).apply();
                if ("key".equals(preference) && settings.getBoolean("monitoringEnabled", false)) {
                    if (settings.getString("key", "").isEmpty()) {
                        settings.edit().putBoolean("monitoringEnabled", false).apply();
                        stopService(new Intent(this, Monitor.class));
                    } else {
                        startForegroundService(new Intent(this, Monitor.class));
                    }
                }
                dialog.dismiss();
                render();
            });
            return true;
        });
        LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(-1, -2);
        layout.bottomMargin = dp(8);
        panel.addView(tile, layout);
    }

    private boolean validCreatorCode(String code) {
        try {
            byte[] digest = java.security.MessageDigest.getInstance("SHA-256")
                    .digest(code.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte value : digest) hex.append(String.format(Locale.ROOT, "%02x", value & 0xff));
            return "881afbf83ed490e011ac7c8eed9c85dcc7356d64bea55808fb2d17d25475b26c".contentEquals(hex);
        } catch (java.security.NoSuchAlgorithmException unavailable) {
            return false;
        }
    }

    private void begin() {
        settings.edit().putBoolean("monitoringEnabled", true).apply();
        startForegroundService(new Intent(this, Monitor.class));
        page = 0;
        render();
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == 1 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            begin();
        }
    }
    private String rawAH(JSONObject row) {
        JSONObject q=row.optJSONObject("unverifiedAH");
        if(q==null)return "";
        return String.format(Locale.forLanguageTag("lt"), "\nAH įrašas %+.1f @ %.2f · %s · geimų/setų vienetai nepatvirtinti; į grafiką neįtraukta",
                q.optDouble("line"),q.optDouble("odds"),q.optString("bookmaker"))
                + " · " + java.text.DateFormat.getTimeInstance().format(new Date(q.optLong("quoted")));
    }

    private void historyFilters() {
        LinearLayout dates=new LinearLayout(this);
        Button date=new Button(this);date.setAllCaps(false);date.setText(historyDate.isEmpty()?"📅 Visos datos":historyDate);
        date.setOnClickListener(v->{
            Calendar c=Calendar.getInstance(TimeZone.getTimeZone("Europe/Vilnius"));
            if(!historyDate.isEmpty())try{String[] d=historyDate.split("-");c.set(Integer.parseInt(d[0]),Integer.parseInt(d[1])-1,Integer.parseInt(d[2]));}catch(Exception ignored){}
            new android.app.DatePickerDialog(this,(picker,year,month,day)->{
                historyDate=String.format(Locale.ROOT,"%04d-%02d-%02d",year,month+1,day);showOlder=false;render();
            },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
        });
        dates.addView(date,new LinearLayout.LayoutParams(0,-2,1));
        Button clear=new Button(this);clear.setAllCaps(false);clear.setText("Visos datos");
        clear.setOnClickListener(v->{historyDate="";showOlder=false;render();});dates.addView(clear);
        panel.addView(dates);
        LinearLayout colors=new LinearLayout(this);
        String[] tiers={"","green","yellow"},names={"Visi","Žalias","Geltonas C"};
        int[] tint={0xffa58aff,0xffa5ff40,0xffffd44d};
        for(int i=0;i<tiers.length;i++) {
            String tier=tiers[i];Button button=new Button(this,null,android.R.attr.borderlessButtonStyle);
            button.setText(names[i]);button.setAllCaps(false);button.setTextSize(12);button.setMinWidth(0);button.setMinimumWidth(0);
            button.setPadding(0,dp(8),0,dp(8));button.setTextColor(tint[i]);
            if(historyTier.equals(tier))button.setBackground(card(tint[i]));
            button.setOnClickListener(v->{historyTier=tier;showOlder=false;render();});colors.addView(button,new LinearLayout.LayoutParams(0,-2,1));
        }
        panel.addView(colors);
        label("Pagal signalo gavimo datą · vienas signalas mačui",13);
    }
    private LinearLayout historyCard(JSONObject row,boolean collapsible) {
        String tier=row.optString("tier");int color=tier.equals("green")?0xffa5ff40:tier.equals("yellow")?0xffffd44d:0xff999999;
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams layout=new LinearLayout.LayoutParams(-1,-2);layout.bottomMargin=dp(14);box.setLayoutParams(layout);
        TextView heading=new TextView(this);heading.setTextColor(color);heading.setTextSize(18);
        heading.setTypeface(android.graphics.Typeface.create("sans-serif-condensed",android.graphics.Typeface.BOLD));
        heading.setIncludeFontPadding(true);heading.setPadding(dp(14),dp(10),dp(14),dp(10));
        heading.setBackground(card(color));heading.setLineSpacing(dp(2),1f);
        String key=SignalPolicy.key(row);boolean expanded=!collapsible||expandedHistory.contains(key);
        String title="AH / ML · "+Bet.ahOutcome(row)+" · "+row.optString("title");
        heading.setText((collapsible?(expanded?"▴ ":"▾ "):"")+title);
        box.addView(heading,new LinearLayout.LayoutParams(-1,-2));
        TextView detail=new TextView(this);detail.setTextSize(14);detail.setTextColor(0xffeeeeee);
        detail.setPadding(dp(5),dp(8),dp(5),dp(8));
        detail.setText(row.optString("detail")+"\nŠaltinis · "+row.optString("statsSource","API Tennis")
                +"\n"+Bet.summary(row)+"\n"+Odds.prematchSummary(row)+"\nPasiūlymas · "+row.optString("betStatus","Koeficientas neišsaugotas")
                +(row.has("profit")?String.format(Locale.forLanguageTag("lt")," · %+.2f €",row.optDouble("profit")):"")
                +"\n"+java.text.DateFormat.getDateTimeInstance().format(new Date(row.optLong("time"))));
        detail.setVisibility(expanded?android.view.View.VISIBLE:android.view.View.GONE);box.addView(detail);
        if(collapsible)heading.setOnClickListener(v->{boolean open=detail.getVisibility()!=android.view.View.VISIBLE;
            detail.setVisibility(open?android.view.View.VISIBLE:android.view.View.GONE);
            if(open)expandedHistory.add(key);else expandedHistory.remove(key);heading.setText((open?"▴ ":"▾ ")+title);});
        return box;
    }
    private void profileIdentity() {
        LinearLayout identity = new LinearLayout(this);
        identity.setOrientation(LinearLayout.VERTICAL);
        identity.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        identity.setPadding(dp(12), dp(16), dp(12), dp(20));

        TextView nickname = new TextView(this);
        nickname.setText(settings.getString("nickname", "Įrašyti slapyvardį"));
        nickname.setTextColor(0xffeeeeff);
        nickname.setTextSize(25);
        nickname.setGravity(android.view.Gravity.CENTER);
        nickname.setTypeface(null, android.graphics.Typeface.BOLD_ITALIC);
        nickname.setPadding(dp(8), dp(8), dp(8), dp(16));
        nickname.setOnClickListener(view -> {
            EditText input = new EditText(this);
            input.setSingleLine(true);
            input.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(30)});
            input.setText(settings.getString("nickname", ""));
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Slapyvardis")
                    .setView(input)
                    .setNegativeButton("Atšaukti", null)
                    .setPositiveButton("Išsaugoti", (dialog, which) -> {
                        String value = input.getText().toString().trim();
                        if (!value.isEmpty()) {
                            settings.edit().putString("nickname", value).apply();
                            nickname.setText(value);
                        }
                    }).show();
        });
        identity.addView(nickname);

        FrameLayout ring = new FrameLayout(this);
        android.graphics.drawable.GradientDrawable border = new android.graphics.drawable.GradientDrawable();
        border.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        border.setColor(0xff14213d);
        border.setStroke(dp(5), 0xff00caff);
        ring.setBackground(border);
        ring.setPadding(dp(10), dp(10), dp(10), dp(10));

        java.io.File avatar = new java.io.File(getFilesDir(), "profile-avatar.jpg");
        android.view.View portrait;
        if (avatar.exists()) {
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setImageURI(android.net.Uri.fromFile(avatar));
            portrait = image;
        } else {
            TextView placeholder = new TextView(this);
            placeholder.setText("👤");
            placeholder.setTextSize(48);
            placeholder.setGravity(android.view.Gravity.CENTER);
            portrait = placeholder;
        }
        android.graphics.drawable.GradientDrawable circle = new android.graphics.drawable.GradientDrawable();
        circle.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        circle.setColor(0xff303c68);
        portrait.setBackground(circle);
        portrait.setClipToOutline(true);
        ring.addView(portrait, new FrameLayout.LayoutParams(-1, -1));
        ring.setContentDescription("Profilio nuotrauka. Palaikyk, kad pakeistum.");
        ring.setOnLongClickListener(view -> {
            new android.app.AlertDialog.Builder(this)
                    .setItems(new String[]{"Pasirinkti nuotrauką"}, (dialog, which) -> {
                        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        pick.addCategory(Intent.CATEGORY_OPENABLE);
                        pick.setType("image/*");
                        try {
                            startActivityForResult(pick, 42);
                        } catch (android.content.ActivityNotFoundException missing) {
                            Toast.makeText(this, "Nėra nuotraukų pasirinkimo programos", Toast.LENGTH_LONG).show();
                        }
                    }).show();
            return true;
        });
        identity.addView(ring, new LinearLayout.LayoutParams(dp(168), dp(168)));

        TextView roi = new TextView(this);
        roi.setText(overallRoi(signalHistory()) + "\nROI");
        roi.setTextColor(0xffeeeeff);
        roi.setTextSize(22);
        roi.setGravity(android.view.Gravity.CENTER);
        roi.setTypeface(null, android.graphics.Typeface.BOLD);
        roi.setPadding(dp(12), dp(10), dp(12), dp(10));
        roi.setBackground(card(0xff48618a));
        LinearLayout.LayoutParams roiLayout = new LinearLayout.LayoutParams(dp(164), -2);
        roiLayout.topMargin = dp(20);
        identity.addView(roi, roiLayout);
        panel.addView(identity);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request!=42||result!=RESULT_OK||data==null||data.getData()==null)return;
        android.graphics.Bitmap bitmap=null;
        java.io.File temporary=new java.io.File(getFilesDir(),"profile-avatar.tmp");
        try {
            android.graphics.BitmapFactory.Options options=new android.graphics.BitmapFactory.Options();options.inJustDecodeBounds=true;
            try(java.io.InputStream stream=getContentResolver().openInputStream(data.getData())){android.graphics.BitmapFactory.decodeStream(stream,null,options);}
            options.inSampleSize=1;while(Math.max(options.outWidth,options.outHeight)/options.inSampleSize>512)options.inSampleSize*=2;
            options.inJustDecodeBounds=false;
            try(java.io.InputStream stream=getContentResolver().openInputStream(data.getData())){bitmap=android.graphics.BitmapFactory.decodeStream(stream,null,options);}
            if(bitmap==null)throw new java.io.IOException("Nepavyko nuskaityti nuotraukos");
            try(java.io.OutputStream output=new java.io.FileOutputStream(temporary)){if(!bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG,90,output))throw new java.io.IOException("Nepavyko išsaugoti");}
            java.nio.file.Files.move(temporary.toPath(),new java.io.File(getFilesDir(),"profile-avatar.jpg").toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            render();
        }catch(Exception invalid){temporary.delete();Toast.makeText(this,"Nuotraukos nepavyko įkelti",Toast.LENGTH_LONG).show();}
        finally{if(bitmap!=null)bitmap.recycle();}
    }

}
