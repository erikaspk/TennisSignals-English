package lt.tenisosignalai;
import java.util.*;
import org.json.*;
final class SignalPolicy {
    static int priority(String tier){return tier.equals("green")?0:tier.equals("yellow")?1:tier.equals("brown")?2:3;}
    static String key(JSONObject row){return row.optString("date",row.optString("event_date"))+":"+row.optString("id",row.optString("event_key"));}
    static JSONObject strongest(List<JSONObject> candidates) {
        JSONObject best=null;
        for(JSONObject row:candidates)if(best==null||priority(row.optString("tier"))<priority(best.optString("tier")))best=row;
        return best;
    }
    /** Keep raw history untouched. First accepted side remains authoritative. */
    static List<JSONObject> history(List<JSONObject> raw) {
        List<JSONObject> ordered=new ArrayList<>(raw);
        ordered.sort(Comparator.comparingLong((JSONObject row)->row.optLong("time")).thenComparing(row->row.optString("player")));
        Map<String,JSONObject> first=new LinkedHashMap<>(),chosen=new LinkedHashMap<>();
        for(JSONObject row:ordered) {
            String key=key(row);
            JSONObject original=first.get(key);
            if(original==null){first.put(key,row);chosen.put(key,row);continue;}
            long capture=original.optLong("statsCaptured",original.optLong("time"));
            long otherCapture=row.optLong("statsCaptured",row.optLong("time"));
            if(original.optString("player").equals(row.optString("player"))&&capture==otherCapture
                    &&priority(row.optString("tier"))<priority(chosen.get(key).optString("tier")))chosen.put(key,row);
        }
        List<JSONObject> result=new ArrayList<>(chosen.values());
        result.sort(Comparator.comparingLong((JSONObject row)->row.optLong("time")).reversed());
        return result;
    }
    static List<JSONObject> displayHistory(List<JSONObject> rows) {
        List<JSONObject> result=new ArrayList<>();
        for(JSONObject original:rows)try {
            JSONObject row=new JSONObject(original.toString());
            if("brown".equals(row.optString("tier"))) {
                row.put("tier","yellow").put("title",row.optString("title").replace("🟤 Rudas C", "🟡 Geltonas C"));
            } else if("yellow".equals(row.optString("tier"))&&row.optInt("policyVersion")<21) {
                row.put("tier","legacy").put("title","Senas A/B · "+row.optString("title"));
            }
            result.add(row);
        }catch(JSONException ignored){}
        return result;
    }
    static String signalDate(JSONObject row) {
        java.text.SimpleDateFormat fmt=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.ROOT);
        fmt.setTimeZone(TimeZone.getTimeZone("Europe/Vilnius"));
        return fmt.format(new Date(row.optLong("time")));
    }
    static List<JSONObject> filter(List<JSONObject> rows,String date,String tier) {
        List<JSONObject> result=new ArrayList<>();
        for(JSONObject row:rows)if((!tier.isEmpty()||!"legacy".equals(row.optString("tier")))&&(date.isEmpty()||signalDate(row).equals(date))&&(tier.isEmpty()||row.optString("tier").equals(tier)))result.add(row);
        return result;
    }
}
