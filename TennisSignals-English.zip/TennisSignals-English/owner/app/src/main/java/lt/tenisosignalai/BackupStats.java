package lt.tenisosignalai;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.time.*;
import java.util.*;

final class BackupStats {
    private final RateGate rate = new RateGate();
    private final Object budgetLock = new Object();
    private final Object liveLock = new Object();
    private Requests requests;
    void setRequests(Requests requests) {this.requests=requests;}
    private android.content.SharedPreferences budget;
    void setBudget(android.content.SharedPreferences preferences) { budget=preferences; }

    static final String HOST = "tennis-api-atp-wta-itf.p.rapidapi.com";
    private static final int DAILY_REQUEST_LIMIT = 5_000;
    private static final int EVENING_RESERVE = 500;
    private static final ZoneId VILNIUS = ZoneId.of("Europe/Vilnius");
    private final FlashStats flash = new FlashStats();
    private volatile String throttledKey = "";
    private volatile long retryAfter;
    private final Map<String,Long> emptyUntil = new java.util.concurrent.ConcurrentHashMap<>();
    private JSONArray liveCache;
    private long liveTime;
    private String liveKey = "";
    private final Map<String, Long> attempted = new HashMap<>();
    private final Map<String, JSONObject> snapshots = new java.util.concurrent.ConcurrentHashMap<>();
    volatile String status = "Atsarginis šaltinis neaktyvus";

    void prepare(List<JSONObject> missing, String key) {
        snapshots.entrySet().removeIf(entry -> System.currentTimeMillis()-entry.getValue().optLong("captured")>SignalTiming.MAX_STATS_AGE);
        if (!MonitoringWindow.backupAllowed()) {
            status = "Matchstat ilsisi iki 10:00 · API Tennis veikia visą parą";
            return;
        }
        boolean blocked=key.isEmpty() || !budgetBlock(key,System.currentTimeMillis()).isEmpty();
        if(blocked) {
            prepareFree(missing,key);
            return;
        }
        String source="Matchstat";
        long now=System.currentTimeMillis();
        emptyUntil.entrySet().removeIf(entry->entry.getValue()<=now);
        missing.removeIf(match -> now<emptyUntil.getOrDefault(source+SignalPolicy.key(match)+scoreKey(match),0L));
        if(missing.isEmpty()){status=source+" · laukiama po tuščių statistikos atsakymų";return;}
        missing.sort(Comparator.comparingLong(m -> attempted.getOrDefault(m.optString("event_key"), 0L)));
        try {
            JSONArray live = live(key);
            if (live == null) throw new IOException("Neteisingas atsakymas");
            int queried = 0, received = 0, matched = 0;
            List<String> ids=new ArrayList<>();
            List<java.util.concurrent.Future<JSONObject>> pending=new ArrayList<>();
            List<JSONObject> synchronous=new ArrayList<>();
            for (JSONObject primary : missing) {
                if (ids.size() >= 2) break;
                String id=primary.optString("event_key");
                attempted.put(id,System.currentTimeMillis()); queried++;
                JSONObject event=find(primary,live);
                if(event==null)continue;
                matched++;
                String eventId=event.optString("id");
                if(!eventId.matches("[0-9]+"))continue;
                ids.add(id);
                if(requests!=null)pending.add(requests.submit(()->snapshot(primary,eventId,key)));
                else synchronous.add(snapshot(primary,eventId,key));
            }
            long deadline=Requests.deadline(4000);
            for(int i=0;i<ids.size();i++) {
                JSONObject result=requests==null?synchronous.get(i):Requests.await(pending.get(i),deadline);
                if(result!=null) {snapshots.put(ids.get(i),result);received++;}
            }
            for(java.util.concurrent.Future<JSONObject> future:pending)if(!future.isDone())future.cancel(true);
            status = source+" · mačų sąraše " + live.length()
                    + " · šiame cikle tikrinta " + queried + " · sutapatinta " + matched
                    + " · statistika panaudota " + received
                    + (queried == 0 ? ""
                        : matched == 0 ? " · nerasta atitikmens pagal datą, vardus ir rezultatą"
                        : received == 0 ? " · negauta tinkamos statistikos" : "");
        } catch (IOException failure) {
            status = "Atsarginis · " + failure.getMessage();
        } catch (JSONException invalid) {
            status = "Atsarginis · neatpažintas duomenų formatas";
        }
    }

    private void prepareFree(List<JSONObject> missing,String key) {
        String freeKey=budget==null?"":budget.getString("flashKey","").trim();
        if(freeKey.isEmpty()) {
            status=key.isEmpty()?"Įvesk atsarginių šaltinių RapidAPI raktą":budgetBlock(key,System.currentTimeMillis());
            return;
        }
        long deadline=Requests.deadline(6200);
        long now=System.currentTimeMillis();
        emptyUntil.entrySet().removeIf(entry->entry.getValue()<=now);
        missing.sort(Comparator.comparingLong(m -> attempted.getOrDefault(m.optString("event_key"),0L)));
        List<JSONObject> remaining=new ArrayList<>(missing.subList(0,Math.min(2,missing.size())));
        for(JSONObject match:remaining)attempted.put(match.optString("event_key"),now);
        StringJoiner diagnostics=new StringJoiner(" · ");
        ExtraStats[] providers=ExtraStats.values();
        for(int i=-1;i<providers.length;i++) {
            if(remaining.isEmpty() || !MonitoringWindow.backupAllowed() || System.nanoTime()>=deadline)break;
            ExtraStats provider=i<0?null:providers[i];
            String label=provider==null?"FlashLive":provider.label;
            List<JSONObject> candidates=new ArrayList<>();
            for(JSONObject match:remaining)if(!emptyUntil.containsKey(emptyKey(label,match)))candidates.add(match);
            if(candidates.isEmpty())continue;
            try {
                JSONArray live=provider==null?flash.live(freeKey,budget):provider.live(freeKey,budget);
                Map<JSONObject,java.util.concurrent.Future<JSONObject>> pending=new LinkedHashMap<>();
                for(JSONObject match:candidates) {
                    if(System.nanoTime()>=deadline || !MonitoringWindow.backupAllowed())break;
                    JSONObject event=provider==null?FlashStats.find(match,live):provider.find(match,live);
                    if(event==null) {
                        emptyUntil.put(emptyKey(label,match),System.currentTimeMillis()+60000);
                        continue;
                    }
                    pending.put(match,requests.submit(()->freeSnapshot(match,event,provider,label,freeKey)));
                }
                int received=0;
                for(Map.Entry<JSONObject,java.util.concurrent.Future<JSONObject>> entry:pending.entrySet()) {
                    JSONObject result=Requests.await(entry.getValue(),deadline);
                    if(result!=null) {
                        JSONObject match=entry.getKey();
                        snapshots.put(match.optString("event_key"),result);
                        remaining.remove(match);
                        received++;
                    }
                }
                for(java.util.concurrent.Future<JSONObject> future:pending.values())if(!future.isDone())future.cancel(true);
                diagnostics.add(label+" "+received+"/"+candidates.size());
            }catch(Exception unavailable){diagnostics.add(label+" neprieinamas");}
        }
        status="Nemokama atsarga · "+diagnostics;
    }

    private JSONObject freeSnapshot(JSONObject match,JSONObject event,ExtraStats provider,String label,String key) {
        try {
            JSONArray stats;
            if(provider==null) {
                String id=event.optString("id");
                if(!id.matches("[A-Za-z0-9]{1,32}"))return null;
                stats=FlashStats.convert(match,event,flash.statistics(id,key,budget));
            }else stats=provider.statistics(match,event,key,budget);
            if(stats==null || !useful(match,stats)) {
                emptyUntil.put(emptyKey(label,match),System.currentTimeMillis()+90000);
                return null;
            }
            return pack(match,stats,label);
        }catch(Exception unavailable){return null;}
    }

    private static boolean useful(JSONObject match,JSONArray stats) {
        Set<String> primaryServe=new HashSet<>();
        JSONArray primary=match.optJSONArray("statistics");
        if(primary!=null)for(int i=0;i<primary.length();i++) {
            JSONObject row=primary.optJSONObject(i);
            if(row!=null && "match".equalsIgnoreCase(row.optString("stat_period"))
                    && "1st serve points won".equalsIgnoreCase(row.optString("stat_name").trim())
                    && row.optInt("stat_won",-1)>=0 && row.optInt("stat_total",0)>0
                    && row.optInt("stat_won")<=row.optInt("stat_total"))primaryServe.add(row.optString("player_key"));
        }
        int serves=0, breaks=0;
        for(int i=0;i<stats.length();i++) {
            JSONObject row=stats.optJSONObject(i);
            if(row==null)continue;
            if("1st serve points won".equals(row.optString("stat_name")))serves++;
            if("break points saved".equals(row.optString("stat_name")))breaks++;
        }
        return serves==2 && (primaryServe.size()<2 || breaks>0);
    }

    private static String emptyKey(String source,JSONObject match) {
        return source+SignalPolicy.key(match)+scoreKey(match);
    }

    private static JSONObject pack(JSONObject match,JSONArray statistics,String source) throws JSONException {
        return new JSONObject().put("statistics",statistics).put("source",source+" / RapidAPI")
                .put("captured",System.currentTimeMillis()).put("scoreKey",scoreKey(match));
    }

    private JSONObject snapshot(JSONObject primary,String eventId,String key) {
        try {
            JSONArray statistics=convert(primary,request("/event/get/statistics/"+eventId,key));
            if(statistics==null) {
                emptyUntil.put(emptyKey("Matchstat",primary),System.currentTimeMillis()+90000);
                return null;
            }
            return pack(primary,statistics,"Matchstat");
        }catch(Exception failure){return null;}
    }

    JSONObject get(String id) {
        JSONObject value=MonitoringWindow.backupAllowed()?snapshots.get(id):null;
        return value!=null && System.currentTimeMillis()-value.optLong("captured")<=SignalTiming.MAX_STATS_AGE?value:null;
    }

    static String scoreKey(JSONObject match) {
        JSONArray scores=match.optJSONArray("scores");
        if(scores==null)return "";
        StringBuilder key=new StringBuilder();
        for(int i=0;i<scores.length();i++){JSONObject set=scores.optJSONObject(i);if(set==null)return "";key.append(set.optInt("score_first",-1)).append(':').append(set.optInt("score_second",-1)).append(',');}
        return key.toString();
    }
    JSONObject get(JSONObject primary) {
        JSONObject value=get(primary.optString("event_key"));
        String score=scoreKey(primary);
        return value!=null&&!score.isEmpty()&&score.equals(value.optString("scoreKey"))?value:null;
    }

    private JSONArray live(String key) throws IOException, JSONException {return live(key,5000);}
    private JSONArray live(String key,long maxAge) throws IOException, JSONException {
        synchronized(liveLock) {
        MonitoringWindow.requireBackupAllowed();
        long now = System.currentTimeMillis();
        if (liveCache == null || now - liveTime > maxAge || !key.equals(liveKey)) {
            liveCache = request("/events/live", key).optJSONArray("results");
            liveTime = now; liveKey = key;
        }
        if (liveCache == null) throw new IOException("Nėra gyvų mačų sąrašo");
        return liveCache;
        }
    }

    JSONObject resolve(JSONObject primary, String key, boolean requireScore) throws IOException, JSONException {
        if (key.isEmpty()) throw new IOException("RapidAPI raktas neįvestas");
        JSONArray events = live(key,requireScore?5000:25000);
        if (requireScore) return find(primary,events);
        JSONObject found = null;
        for (int i=0; i<events.length(); i++) {
            JSONObject e=events.optJSONObject(i);
            if(e==null || !primary.optString("event_date").equals(e.optString("dateOnly"))) continue;
            boolean direct=same(primary.optString("event_first_player"),e.optString("participant1"))
                    && same(primary.optString("event_second_player"),e.optString("participant2"));
            boolean reverse=same(primary.optString("event_first_player"),e.optString("participant2"))
                    && same(primary.optString("event_second_player"),e.optString("participant1"));
            if(!direct&&!reverse)continue;
            if(found!=null) return null;
            found=e;
        }
        return found;
    }

    static int dailyLimit(long now) {
        return Instant.ofEpochMilli(now).atZone(VILNIUS).getHour()<20
                ? DAILY_REQUEST_LIMIT-EVENING_RESERVE : DAILY_REQUEST_LIMIT;
    }

    private int usedToday(long now) {
        String day=Instant.ofEpochMilli(now).atZone(VILNIUS).toLocalDate().toString();
        return budget!=null && day.equals(budget.getString("rapidBudgetDay",""))
                ? budget.getInt("rapidBudgetUsed",0) : 0;
    }

    String budgetBlock(String key,long now) {
        if (now<RapidQuota.blockedUntil(budget,"rapid",key)) return "Matchstat · RapidAPI plano kvota išnaudota";
        if (now<retryAfter && key.equals(throttledKey)) return "Matchstat pristabdytas po RapidAPI atsakymo";
        if (usedToday(now)<dailyLimit(now)) return "";
        return dailyLimit(now)<DAILY_REQUEST_LIMIT
                ? "Matchstat · 500 užklausų rezervas atsivers 20:00 LT"
                : "Matchstat · pasiektas 5 000 užklausų dienos limitas";
    }

    JSONObject request(String path, String key) throws IOException, JSONException {
        MonitoringWindow.requireBackupAllowed();
        if(key.isEmpty())throw new IOException("RapidAPI raktas neįvestas");
        String block=budgetBlock(key,System.currentTimeMillis());
        if(!block.isEmpty())throw new IOException(block);
        try {rate.acquire();}catch(InterruptedException stopped){Thread.currentThread().interrupt();throw new IOException("Užklausa sustabdyta");}
        MonitoringWindow.requireBackupAllowed();
        synchronized(budgetLock) {
            long now=System.currentTimeMillis();
            block=budgetBlock(key,now);
            if(!block.isEmpty())throw new IOException(block);
            if (budget != null) {
                String day=Instant.ofEpochMilli(now).atZone(VILNIUS).toLocalDate().toString();
                String category=path.startsWith("/events/")?"List":path.startsWith("/odds/pre-match/")?"Pre"
                        :path.startsWith("/event/recent-odds/")?"Live":"Stats";
                boolean sameDay=day.equals(budget.getString("rapidBudgetDay",""));
                android.content.SharedPreferences.Editor edit=budget.edit().putString("rapidBudgetDay",day)
                        .putInt("rapidBudgetUsed",usedToday(now)+1);
                for(String type:new String[]{"List","Pre","Live","Stats"}) {
                    String counter="rapidBudget"+type;
                    edit.putInt(counter,(sameDay?budget.getInt(counter,0):0)+(type.equals(category)?1:0));
                }
                if(!edit.commit())throw new IOException("nepavyko išsaugoti užklausų skaitiklio");
            }
        }
        MonitoringWindow.requireBackupAllowed();
        HttpURLConnection connection = (HttpURLConnection) new URL("https://" + HOST + "/tennis/v2/extend/api" + path).openConnection();
        connection.setConnectTimeout(4000);
        connection.setReadTimeout(4000);
        connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("X-RapidAPI-Host", HOST);
        connection.setRequestProperty("X-RapidAPI-Key", key);
        try {
            int code = connection.getResponseCode();
            synchronized(budgetLock) {
                RapidQuota.observe(connection,budget,"rapid",key,System.currentTimeMillis());
            }
            if (code == 401 || code == 403 || code == 429) {
                long seconds=code==429?120:900;
                try {seconds=Math.max(seconds,Math.min(86400,Long.parseLong(connection.getHeaderField("Retry-After"))));}
                catch(NumberFormatException ignored){}
                throttledKey=key;
                retryAfter=Math.max(retryAfter,System.currentTimeMillis()+seconds*1000);
            }
            if (code == 401 || code == 403) throw new IOException("HTTP " + code + " · RapidAPI atmetė prieigą; palygink raktą su svetainės Code snippet");
            if (code == 429) throw new IOException("užklausų limitas pasiektas");
            if (code != 200) throw new IOException("HTTP " + code);
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder body = new StringBuilder();
                char[] buffer=new char[8192];int read;
                while((read=reader.read(buffer))!=-1) {
                    if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Užklausa sustabdyta");
                    body.append(buffer,0,read);
                }
                JSONObject result = new JSONObject(body.toString());
                if (!result.optBoolean("success")) throw new IOException("užklausa atmesta");
                return result;
            }
        } finally { connection.disconnect(); }
    }

    static String nameKey(String name) {
        String normalized = Normalizer.normalize(name, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z ]", " ").trim().replaceAll(" +", " ");
        String[] parts = normalized.split(" ");
        if (parts.length < 2 || parts[0].isEmpty()) return "";
        // Accept abbreviation only for first name. Preserve the complete family name.
        return parts[0].charAt(0) + " " + String.join(" ", Arrays.copyOfRange(parts, 1, parts.length));
    }

    private static String[] tokens(String name) {
        return Normalizer.normalize(name, Normalizer.Form.NFD).replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT).replaceAll("[^a-z ]", " ").trim().split(" +");
    }

    static boolean same(String a, String b) {
        String[] left = tokens(a), right = tokens(b);
        if (left.length < 2 || left.length != right.length) return false;
        for (int i = 0; i < left.length; i++) {
            if (left[i].equals(right[i])) continue;
            if (i == left.length - 1 || (left[i].length() != 1 && right[i].length() != 1)
                    || left[i].charAt(0) != right[i].charAt(0)) return false;
        }
        return true;
    }

    static JSONObject find(JSONObject primary, JSONArray live) {
        JSONObject found = null;
        for (int i = 0; i < live.length(); i++) {
            JSONObject event = live.optJSONObject(i);
            if (event == null || !"InPlay".equalsIgnoreCase(event.optString("status"))
                    || !primary.optString("event_date").equals(event.optString("dateOnly"))) continue;
            String first = event.optString("participant1"), second = event.optString("participant2");
            boolean direct = same(primary.optString("event_first_player"), first) && same(primary.optString("event_second_player"), second);
            boolean reverse = same(primary.optString("event_first_player"), second) && same(primary.optString("event_second_player"), first);
            if ((!direct && !reverse) || !scoreMatches(primary, event.optString("score"), reverse)) continue;
            if (found != null) return null;
            found = event;
        }
        return found;
    }

    static boolean scoreMatches(JSONObject primary, String score, boolean reverse) {
        JSONArray scores = primary.optJSONArray("scores");
        String[] sets = score.trim().split(",");
        if (scores == null || scores.length() == 0 || scores.length() != sets.length) return false;
        for (int i = 0; i < sets.length; i++) {
            String[] pair = sets[i].trim().split("\\s*-\\s*");
            if (pair.length != 2 || !pair[0].matches("[0-7]") || !pair[1].matches("[0-7]")) return false;
            JSONObject set = scores.optJSONObject(i);
            if (set == null || Integer.parseInt(pair[reverse ? 1 : 0]) != set.optInt("score_first", -1)
                    || Integer.parseInt(pair[reverse ? 0 : 1]) != set.optInt("score_second", -1)) return false;
        }
        return true;
    }

    static JSONArray convert(JSONObject primary, JSONObject detail) throws JSONException {
        if (detail.has("result")) detail = detail.optJSONObject("result");
        if (detail == null || !primary.optString("event_date").equals(detail.optString("dateOnly"))) return null;
        JSONObject first = detail.optJSONObject("player1"), second = detail.optJSONObject("player2");
        if (first == null || second == null) return null;
        boolean direct = same(primary.optString("event_first_player"), first.optString("name"))
                && same(primary.optString("event_second_player"), second.optString("name"));
        boolean reverse = same(primary.optString("event_first_player"), second.optString("name"))
                && same(primary.optString("event_second_player"), first.optString("name"));
        if (!direct && !reverse) return null;
        JSONObject periods = detail.optJSONObject("statistics");
        JSONObject all = periods == null ? null : periods.optJSONObject("ALL");
        JSONObject service = all == null ? null : all.optJSONObject("service");
        JSONObject games = all == null ? null : all.optJSONObject("games");
        JSONObject gamesWon = games == null ? null : games.optJSONObject("gamesWon");
        JSONObject returns = all == null ? null : all.optJSONObject("return");
        if (all == null) return null;
        JSONArray result = new JSONArray();
        JSONArray scores = primary.optJSONArray("scores");
        if (scores == null || scores.length() == 0) return null;
        for (int i = 0; i < 2; i++) {
            String side = i == 0 ? "first" : "second";
            String secondary = "player" + ((reverse ? 1 - i : i) + 1);
            int totalGames = 0, tieBreakWins = 0;
            for (int j = 0; j < scores.length(); j++) {
                JSONObject set = scores.optJSONObject(j);
                if (set == null || set.optInt("score_" + side, -1) < 0) return null;
                totalGames += set.optInt("score_" + side);
                if (set.optInt("score_" + side) == 7
                        && set.optInt("score_" + (i == 0 ? "second" : "first")) == 6) tieBreakWins++;
            }
            JSONObject count = gamesWon == null ? null : gamesWon.optJSONObject(secondary);
            int actualGames = count == null ? -1 : count.optInt("value", -1);
            if (actualGames < 0) {
                int held = value(games, "serviceGamesWon", secondary);
                int broken = value(returns, "breakPointsScored", secondary);
                if (held < 0 || broken < 0) return null;
                actualGames = held + broken + tieBreakWins;
            }
            if (actualGames != totalGames) return null;
            String player = primary.optString(side + "_player_key");
            if (!metric(result, service, "firstServePointsAccuracy", secondary, player, "1st serve points won")) {
                String opponent = "player" + ((reverse ? i : 1 - i) + 1);
                JSONObject category = returns == null ? null : returns.optJSONObject("firstReturnPoints");
                JSONObject received = category == null ? null : category.optJSONObject(opponent);
                if (received == null) return null;
                int total = received.optInt("total", -1), lost = received.optInt("value", -1);
                if (player.isEmpty() || total <= 0 || lost < 0 || lost > total) return null;
                result.put(new JSONObject().put("player_key", player).put("stat_period", "match")
                        .put("stat_name", "1st serve points won").put("stat_won", total - lost).put("stat_total", total));
            }
            metric(result, service, "breakPointsSaved", secondary,
                    primary.optString(side + "_player_key"), "break points saved");
        }
        return result;
    }

    private static int value(JSONObject group, String metric, String side) {
        JSONObject category = group == null ? null : group.optJSONObject(metric);
        JSONObject count = category == null ? null : category.optJSONObject(side);
        return count == null ? -1 : count.optInt("value", -1);
    }

    private static boolean metric(JSONArray result, JSONObject service, String metric, String secondary,
                                  String player, String label) throws JSONException {
        if (service == null) return false;
        JSONObject category = service.optJSONObject(metric);
        JSONObject value = category == null ? null : category.optJSONObject(secondary);
        if (value == null) return false;
        int won = value.optInt("value", -1), total = value.optInt("total", -1);
        if (player.isEmpty() || won < 0 || total < 0 || won > total) return false;
        result.put(new JSONObject().put("player_key", player).put("stat_period", "match")
                .put("stat_name", label).put("stat_won", won).put("stat_total", total));
        return true;
    }
}
