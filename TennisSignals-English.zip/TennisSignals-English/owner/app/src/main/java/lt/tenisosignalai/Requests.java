package lt.tenisosignalai;
import java.util.concurrent.*;

/** Bounded network work; callers share a single monotonic deadline, never chained timeouts. */
final class Requests implements AutoCloseable {
    private final ThreadPoolExecutor pool = new ThreadPoolExecutor(6,6,0,TimeUnit.MILLISECONDS,
            new ArrayBlockingQueue<>(24));
    <T> Future<T> submit(Callable<T> work) {
        try {return pool.submit(work);}catch(RejectedExecutionException full){return CompletableFuture.completedFuture(null);}
    }
    static long deadline(long millis) {return System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(millis);}
    static <T> T await(Future<T> future,long deadline) {
        if(future==null)return null;
        try {
            if(future.isDone())return future.get();
            long remaining=deadline-System.nanoTime();
            return remaining<=0?null:future.get(remaining,TimeUnit.NANOSECONDS);
        }catch(InterruptedException stopped){Thread.currentThread().interrupt();return null;}
        catch(ExecutionException|TimeoutException|CancellationException failed){return null;}
    }
    @Override public void close(){pool.shutdownNow();}
}
