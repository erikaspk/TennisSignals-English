package lt.tenisosignalai;
import org.json.*;
import java.util.*;

final class SecondaryOdds {
    private final BackupStats transport;
    private final Map<String,JSONObject> preCache = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<String,Long> failed = new java.util.concurrent.ConcurrentHashMap<>();
    private String cacheKey="";
    volatile String status="";
    SecondaryOdds(BackupStats transport) {this.transport=transport;}
    private synchronized void keyChanged(String key) {if(!key.equals(cacheKey)){preCache.clear(); failed.clear();cacheKey=key;}}
    JSONObject prematch(JSONObject match,String key) {
        if(!MonitoringWindow.backupAllowed()){status="Matchstat koeficientai tik 10–22 val. LT";return null;}
        keyChanged(key);
        String id=match.optString("event_key")+":"+match.optString("event_date");
        if(preCache.containsKey(id))return preCache.get(id);
        if(System.currentTimeMillis()-failed.getOrDefault(id,0L)<60000)return null;
        try {
            JSONObject event=transport.resolve(match,key,false);
            if(event==null){status="Matchstat: mačas nesutapatintas";failed.put(id,System.currentTimeMillis());return null;}
            String eventId=event.optString("id");if(!eventId.matches("[0-9]+"))return null;
            JSONObject response=transport.request("/odds/pre-match/"+eventId,key);
            if(!namesMatch(response,event)){status="Matchstat: prematch žaidėjai nesutampa";return null;}
            long start=response.optLong("startTimestamp",0)*1000L;
            boolean reverse=BackupStats.same(match.optString("event_first_player"),event.optString("participant2"));
            JSONObject quote=Odds.prematchSecondary(response,start,reverse,System.currentTimeMillis());
            if(quote==null){status="Matchstat: prematch koeficientų nėra";failed.put(id,System.currentTimeMillis());}
            else {quote.put("eventId",eventId);if(preCache.size()>256)preCache.clear();preCache.put(id,quote);status="Matchstat: prematch gautas";}
            return quote;
        }catch(Exception e){status="Matchstat prematch · "+e.getMessage();if(!Thread.currentThread().isInterrupted())failed.put(id,System.currentTimeMillis());return null;}
    }
    JSONObject live(JSONObject match,String primarySide,String key) {
        JSONObject both=bothLive(match,key);
        return both==null?null:both.optJSONObject(primarySide.equals("1")?"first":"second");
    }
    JSONObject bothLive(JSONObject match,String key) {
        try {
            if(!MonitoringWindow.backupAllowed())return reasons("Matchstat AH tik 10–22 val. LT");
            keyChanged(key);
            JSONObject event=transport.resolve(match,key,true);
            if(event==null)return reasons("Matchstat AH: nesutapo mačas arba rezultatas");
            String eventId=event.optString("id");if(!eventId.matches("[0-9]+"))return null;
            JSONObject response=transport.request("/event/recent-odds/get/"+eventId+"?inplay=true",key);
            long received=System.currentTimeMillis();
            boolean reverse=BackupStats.same(match.optString("event_first_player"),event.optString("participant2"));
            JSONObject both=new JSONObject();
            for(String side:new String[]{"1","2"}) {
                JSONObject out=Odds.liveSecondary(response,side,reverse,received);
                JSONObject quote=out.optJSONObject("bet"),raw=out.optJSONObject("unverifiedAH");
                JSONArray offers=out.optJSONArray("offers");
                if(offers!=null)for(int j=0;j<offers.length();j++)offers.getJSONObject(j).put("eventId",eventId).put("received",received);
                if(quote!=null)quote.put("eventId",eventId).put("received",received);
                if(raw!=null)raw.put("eventId",eventId).put("received",received);
                both.put(side.equals("1")?"first":"second",out);
            }
            return both;
        }catch(Exception e){return reasons("Matchstat AH · "+e.getMessage());}
    }
    private static JSONObject reasons(String reason) {
        try{return new JSONObject().put("first",new JSONObject().put("reason",reason))
                .put("second",new JSONObject().put("reason",reason));}catch(JSONException ignored){return null;}
    }
    private static boolean namesMatch(JSONObject r,JSONObject event) {
        JSONObject p1=r.optJSONObject("player1"),p2=r.optJSONObject("player2");
        return p1!=null&&p2!=null&&BackupStats.same(p1.optString("name"),event.optString("participant1"))
                && BackupStats.same(p2.optString("name"),event.optString("participant2"));
    }
}
