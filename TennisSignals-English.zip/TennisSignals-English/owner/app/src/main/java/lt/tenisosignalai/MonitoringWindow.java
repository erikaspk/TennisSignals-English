package lt.tenisosignalai;

import java.io.IOException;
import java.time.Instant;
import java.time.ZoneId;

final class MonitoringWindow {

    static boolean workingTime(long timestamp) {
        int hour = Instant.ofEpochMilli(timestamp).atZone(ZoneId.of("Europe/Vilnius")).getHour();
        return hour >= 10 && hour < 22;
    }

    static boolean allowed() {
        return !Thread.currentThread().isInterrupted();
    }

    static boolean backupAllowed() {
        return allowed() && workingTime(System.currentTimeMillis());
    }

    static void requireBackupAllowed() throws IOException {
        if (!backupAllowed()) throw new IOException("Matchstat ne darbo laikas · API Tennis veikia visą parą");
    }

    static void requireAllowed() throws IOException {
        if (!allowed()) throw new IOException("Stebėjimas pristabdytas");
    }
}
