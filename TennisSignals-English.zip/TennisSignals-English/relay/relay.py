"""Small single-publisher relay. Run behind a trusted HTTPS reverse proxy."""
import argparse
from contextlib import contextmanager
import hashlib
import hmac
import json
import math
import os
import re
import secrets
import sqlite3
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

LIMIT = 8 * 1024 * 1024
TOKEN = re.compile(r"[A-Za-z0-9_-]{32,256}")
FIELDS = {"id", "date", "tier", "title", "detail", "time", "statsSource", "outcome", "betStatus", "profit"}
BET_FIELDS = {"unit", "line", "odds", "stake", "bookmaker", "quoted", "source"}
PRE_FIELDS = {"odds", "bookmaker", "source"}


def encode(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()


@contextmanager
def db(path):
    connection = sqlite3.connect(path, timeout=5)
    try:
        with connection:
            connection.execute("CREATE TABLE IF NOT EXISTS feed (id INTEGER PRIMARY KEY, body TEXT, updated INTEGER)")
            connection.execute("CREATE TABLE IF NOT EXISTS members (digest TEXT PRIMARY KEY, expires INTEGER)")
            yield connection
    finally:
        connection.close()


def digest(token):
    return hashlib.sha256(token.encode()).hexdigest()


def revolut_link(value):
    if not value:
        return ""
    url = urlsplit(value)
    host = url.hostname or ""
    if url.scheme != "https" or url.username is not None or url.password is not None or not (
        host in {"revolut.com", "revolut.me"} or host.endswith(".revolut.com")
    ):
        raise ValueError("Set a public HTTPS Revolut checkout URL")
    return value


def select(obj, keys):
    return {key: value for key, value in obj.items() if key in keys and type(value) in (str, int, float)}


def normalize(payload):
    if not isinstance(payload, dict) or payload.get("schema") != 1 or not isinstance(payload.get("signals"), list):
        raise ValueError("Invalid schema")
    signals = {}
    for item in payload["signals"]:
        if not isinstance(item, dict):
            raise ValueError("Invalid signal")
        row = select(item, FIELDS)
        if (not isinstance(row.get("id"), str) or not row["id"] or not isinstance(row.get("date"), str)
                or row.get("tier") not in ("green", "yellow") or type(row.get("time")) is not int
                or not isinstance(row.get("title"), str) or not row["title"]
                or row.get("outcome") not in ("Vyksta", "Laimėta", "Pralaimėta", "Nutraukta")):
            raise ValueError("Invalid signal")
        bet = item.get("bet")
        if isinstance(bet, dict):
            bet = select(bet, BET_FIELDS)
            odds = bet.get("odds")
            if type(odds) not in (int, float) or not math.isfinite(odds) or odds <= 1:
                raise ValueError("Invalid odds")
            row["bet"] = bet
        pre = item.get("prematch")
        if isinstance(pre, dict):
            row["prematch"] = select(pre, PRE_FIELDS)
        signals[(row["date"], row["id"])] = row
    return sorted(signals.values(), key=lambda row: row["time"], reverse=True)


class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(12)

    def respond(self, status, body=None, etag=None):
        self.send_response(status)
        self.send_header("Cache-Control", "private, no-store")
        self.send_header("Vary", "Authorization, X-Checkout-Mode")
        if etag:
            self.send_header("ETag", etag)
        if body is not None:
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if body is not None:
            self.wfile.write(body)

    def token(self):
        auth = self.headers.get("Authorization", "")
        return auth[7:] if auth.startswith("Bearer ") and TOKEN.fullmatch(auth[7:]) else ""

    def do_PUT(self):
        if self.path != "/v1/feed":
            self.respond(404)
            return
        if not hmac.compare_digest(self.token(), self.server.owner):
            self.respond(403)
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 < size <= LIMIT:
                self.respond(413)
                return
            rows = normalize(json.loads(self.rfile.read(size)))
            body = encode(rows).decode()
        except (ValueError, TypeError, OverflowError, RecursionError, OSError):
            self.respond(400)
            return
        with db(self.server.database) as connection:
            connection.execute("INSERT OR REPLACE INTO feed VALUES (1, ?, ?)", (body, int(time.time())))
        self.respond(204)

    def do_GET(self):
        if self.path == "/health":
            self.respond(200, b'{"ok":true}')
            return
        if self.path != "/v1/feed":
            self.respond(404)
            return
        token = self.token()
        now = int(time.time())
        with db(self.server.database) as connection:
            member = connection.execute("SELECT expires FROM members WHERE digest=? AND expires>?",
                                        (digest(token), now)).fetchone() if token else None
            feed = connection.execute("SELECT body, updated FROM feed WHERE id=1").fetchone()
        rows = json.loads(feed[0]) if feed else []
        updated = feed[1] if feed else 0
        # Keep settled history for members. Stop showing old pending items as live when the publisher disconnects.
        live = now - updated <= 180
        if not member:
            rows = [row for row in rows if row["outcome"] == "Vyksta"][:3] if live else []
        response = {"schema": 1, "signals": rows, "updated": updated, "live": live, "member": bool(member),
                    "expires": member[0] if member else 0}
        if self.headers.get("X-Checkout-Mode") == "direct":
            response["checkout"] = self.server.checkout
            if self.server.transfer:
                response["transfer"] = self.server.transfer
        data = encode(response)
        etag = '"' + hashlib.sha256(data).hexdigest() + '"'
        if self.headers.get("If-None-Match") == etag:
            self.respond(304, etag=etag)
        else:
            self.respond(200, data, etag)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", default=os.environ.get("RELAY_DB", "relay.sqlite3"))
    commands = parser.add_subparsers(dest="command", required=True)
    serve = commands.add_parser("serve")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8080)
    add = commands.add_parser("member")
    add.add_argument("--days", type=int, choices=[7, 30], required=True)
    revoke = commands.add_parser("revoke")
    revoke.add_argument("token")
    args = parser.parse_args()
    os.umask(0o077)
    database = str(Path(args.db).resolve())
    with db(database):
        pass
    if args.command == "member":
        token = secrets.token_urlsafe(32)
        with db(database) as connection:
            connection.execute("INSERT INTO members VALUES (?, ?)", (digest(token), int(time.time()) + args.days * 86400))
        print(token)
    elif args.command == "revoke":
        with db(database) as connection:
            connection.execute("DELETE FROM members WHERE digest=?", (digest(args.token),))
    else:
        owner = os.environ.get("RELAY_OWNER_TOKEN", "")
        if not TOKEN.fullmatch(owner):
            parser.error("RELAY_OWNER_TOKEN must be a random token of at least 32 characters")
        with ThreadingHTTPServer((args.host, args.port), Handler) as server:
            server.database = database
            server.owner = owner
            server.checkout = {plan: revolut_link(os.environ.get("REVOLUT_" + plan.upper() + "_URL", ""))
                               for plan in ("week", "month")}
            transfer = {field: os.environ.get("TRANSFER_" + field.upper(), "").strip()
                        for field in ("beneficiary", "iban", "bic")}
            if any(transfer.values()) and not all(transfer.values()):
                parser.error("Set all three TRANSFER_BENEFICIARY, TRANSFER_IBAN and TRANSFER_BIC")
            server.transfer = transfer if all(transfer.values()) else None
            server.serve_forever()


if __name__ == "__main__":
    main()
