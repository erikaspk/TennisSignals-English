# Tennis Signals English

Rinkinyje yra du Android projektai ir signalų serveris.

| Katalogas | Paskirtis |
| --- | --- |
| `owner` | Lietuviška v35. V34 signalų taisyklės su pridėtu perdavimu per HTTPS. |
| `viewer` | Angliška v1.0. Gauna paruoštus signalus, rodo aktyvius mačus, istoriją, vidutinį koeficientą, modelio pelną, ROI, grafiką, slapyvardį ir profilio nuotrauką. |
| `relay` | Python ir SQLite serveris. Jis saugo naujausią signalų bei jų rezultatų rinkinį ir tikrina narystės kodus. |

Angliškoje programėlėje atnaujinimai gaunami kas 15 sekundžių, kol ji atidaryta. Siuntėjas sinchronizuoja maždaug kas 10 sekundžių, kol įjungtas v35 stebėjimas. Užvertos angliškos programėlės pranešimai šioje versijoje nesiunčiami. Nuotrauka ir slapyvardis saugomi tame telefone.

## 1. Paleisti serverį

Paleisk serveryje su Python 3.10 arba naujesne versija. Naudok nuolatinį diską SQLite failui. Nukopijuok `relay/relay.py` į serverį, o mokėjimo rekvizitų failą laikyk atskirai nuo GitHub projekto.

```bash
umask 077
export RELAY_DB="$PWD/relay.sqlite3"
export RELAY_OWNER_TOKEN="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')"
source ./revolut-transfer-private.env
python3 relay.py serve --host 127.0.0.1 --port 8080
```

Siuntėjo raktą išsaugok saugioje serverio konfigūracijoje ir naudok tą pačią reikšmę po perkrovimo. Nustatyk HTTPS atvirkštinį tarpinį serverį, kad viešas domenas persiųstų užklausas į `127.0.0.1:8080`. Pavyzdinė „Caddy“ konfigūracija

```caddyfile
signals.example.com {
    reverse_proxy 127.0.0.1:8080
}
```

Patikrink `https://signals.example.com/health`. Gamyboje paleisk procesą kaip automatiškai paleidžiamą tarnybą.

Jei turi viešas „Revolut“ apmokėjimo nuorodas, nustatyk `REVOLUT_WEEK_URL` ir `REVOLUT_MONTH_URL`. Tiesioginio APK mygtukas atidarys atitinkamą nuorodą. Kai nuorodos nėra, mygtukas rodo banko pavedimo rekvizitus ir mokėjimo paskirtį. Patikrinęs įplauką, sugeneruok klientui kodą. Narystė prasideda sugeneravus kodą.

```bash
python3 relay.py member --days 7
python3 relay.py member --days 30
python3 relay.py revoke NARIO_KODAS
```

Nemokamai rodomi iki trijų naujausių aktyvių mačų, kuriems siuntėjas jau sugeneravo signalą. Narystė atrakina pilną srautą ir istoriją. Savaitė kainuoja 4,99 €, 30 dienų kainuoja 9,99 €. Mokėjimas patikrinamas rankiniu būdu ir automatiškai nesikartoja.

## 2. Surinkti Android failus per GitHub

Išskleisk archyvą ir įkelk jo vidinio katalogo turinį į atskirą GitHub repozitoriją. Įtrauk `.github/workflows/build.yml`. Alternatyviai įkelk `TennisSignals-English.zip` į repozitorijos šaknį ir atskirai sukurk `.github/workflows/build.yml`, į jį nukopijuodamas rinkinyje esantį workflow.

Jei jau turi veikiantį HTTPS adresą, įrašyk jį į repozitorijos `RELAY_URL` kintamąjį. Taip angliška programėlė jį turės iš anksto. Kitais atvejais adresą įvesk per `Profile → Feed connection / Access code`.

Paleisk `Actions → Build Tennis Signals`. Darbo rezultatuose ieškok šių failų

- `TennisSignals-owner` → `TenisoSignalai-owner-v35.apk`
- `TennisSignals-viewer` → `TennisSignals-English-direct.apk` ir `TennisSignals-English-play-unsigned.aab`

Lietuviškos versijos paketo ID yra toks pats kaip v34. Kad įdiegtum kaip atnaujinimą ir išsaugotum vietinius duomenis, pasirašyk tuo pačiu raktu. Jei v34 naudojo standartinį debug keystore, workflow gali atkurti tą raktą iš `ANDROID_DEBUG_KEYSTORE_BASE64`. Jei v34 pasirašei kitu būdu, naudok tą patį pasirašymo būdą ir raktą.

## 3. Suporuoti

1. Lietuviškoje v35 įjunk `Profilis → Signalų persiuntimas`, įvesk HTTPS adresą ir siuntėjo raktą. Paleisk stebėjimą.
2. Angliškoje programėlėje atsidaryk `Profile → Feed connection / Access code`. Jei serverio adresas jau įrašytas surenkant, užtenka nario kodo pilnai prieigai.
3. Patikrink, ar abu telefonai rodo tą patį signalą, o uždarius mačą angliškoje istorijoje atsiranda rezultatas.

## Google Play ir mokėjimai

AAB taiko Android API 36 ir turi būti pasirašytas Play Console įkėlimo raktu. Play variante yra narystės informacija ir kodo įvedimas. Pavedimo rekvizitai ir „Revolut“ mygtukas skirti tiesioginiam APK. Play varianto paruošimas peržiūrai nesuteikia publikavimo leidimo. Prieš pateikiant peržiūrai reikia įvertinti mokamų statymų signalų bei koeficientų rodymą pagal Google Play taisykles ir turimų duomenų platinimo teises. Prieš priimant komercinius mokėjimus patikrink su „Revolut“, ar paskyra tinkama šiai veiklai.

- [Google Play tikslinio API reikalavimai](https://support.google.com/googleplay/android-developer/answer/11926878)
- [Google Play statymų ir lošimų politika](https://support.google.com/googleplay/android-developer/answer/9877032)
- [Google Play mokėjimų politika](https://support.google.com/googleplay/android-developer/answer/10281818)
- [Revolut Business sąlygos Lietuvoje](https://www.revolut.com/en-LT/legal/business-terms/)
